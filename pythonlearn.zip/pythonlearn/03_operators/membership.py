my_list = [1, 2, 3, 4, 5]

print(3 in my_list)

print(7 in my_list)

print(6 not in my_list)

print('t' in 'python')

list = ['ferrari', 'audibmw']
print('ferrari' in list)

print('audi' in list)  #list only checks the index