
ticket = True

id_card = False

print(ticket and id_card, ": you are allowed")

print(ticket or id_card, ": you are  allowed")

print(not(ticket and id_card), ": you are allowed")

