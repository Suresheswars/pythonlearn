
x = [1, 2, 3]
y = [1, 2, 3]

print(x is y)
print(x is not y )

print(id(x))
print(id(y))

############
a = 5
b = 5
print(a is b)

print(id(a))
print(id(b))

############

c = (1, 2, 3)
d = (1, 2, 3)

print(c is d)

print(id(c))
print(id(d))


