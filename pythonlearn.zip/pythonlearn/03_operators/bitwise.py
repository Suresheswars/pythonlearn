# a = 6
# # b = 2
# #
# # print(a ^ b)
#
# a = 6
# print(~a)


a = 4 #we are using 2 to shift the 4
b = 2

print(a >> b)