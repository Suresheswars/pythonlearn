a = 7
print(a)

a += 3 #(a = a + 3)
print(a)

a -= 2
print(a)

a *= 2
print(a)

a **=2
print(a)