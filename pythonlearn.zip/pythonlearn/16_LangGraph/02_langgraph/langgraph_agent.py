import subprocess, re, requests, os, time, threading, hashlib
from datetime import datetime
from typing import TypedDict, Literal
from http.server import HTTPServer, BaseHTTPRequestHandler
from fastapi import FastAPI, Request
import uvicorn
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma
from langchain_core.documents import Document
import config

os.environ["OPENAI_API_KEY"] = config.OPENAI_API_KEY
app = FastAPI()
pending_approvals = {}
MAX_RETRIES = 3
CHROMA_PATH = "./chroma_db"
RAG_REFRESH_INTERVAL = 30
vector_store = None
last_content_hash = None

class RemediationState(TypedDict):
    alert_name: str
    container: str
    runbook_content: str
    command: str
    human_approved: bool
    verified: bool
    retry_count: int
    status: str

class MetricsHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/metrics':
            try:
                self.send_response(200)
                self.send_header('Content-type', 'text/plain')
                self.end_headers()
                self.wfile.write(self.get_metrics().encode())
            except: pass
    
    def log_message(self, *args): pass
    
    def get_metrics(self):
        result = subprocess.getoutput('docker stats --no-stream --format "{{.Name}}|{{.CPUPerc}}"')
        lines = ["# TYPE container_cpu_percent gauge", "# TYPE httpd_service_up gauge"]
        for row in result.strip().split('\n'):
            if '|' in row:
                parts = row.split('|')
                name, cpu = parts[0].strip(), parts[1].strip().replace('%', '')
                try: lines.append(f'container_cpu_percent{{name="{name}"}} {float(cpu)}')
                except: pass
        httpd_check = subprocess.getoutput('docker exec httpd-server ps aux')
        httpd_up = 1 if any('httpd' in l and 'defunct' not in l and 'Ss' in l for l in httpd_check.split('\n')) else 0
        lines.append(f'httpd_service_up {httpd_up}')
        return '\n'.join(lines) + '\n'

def start_exporter():
    HTTPServer(('0.0.0.0', 9200), MetricsHandler).serve_forever()

def fetch_runbooks():
    url = f"{config.CONFLUENCE_URL}/rest/api/content/{config.CONFLUENCE_PARENT_PAGE_ID}/child/page?expand=body.storage"
    try:
        response = requests.get(url, auth=(config.CONFLUENCE_USER, config.CONFLUENCE_TOKEN))
        if response.status_code == 200:
            return [{'title': p['title'], 'content': re.sub('<[^<]+?>', '', p['body']['storage']['value']).strip()}
                    for p in response.json().get('results', [])]
    except: pass
    return []

def init_vector_store():
    global vector_store
    vector_store = Chroma(collection_name="runbooks", embedding_function=OpenAIEmbeddings(model="text-embedding-3-small"), persist_directory=CHROMA_PATH)

def refresh_embeddings(force=False):
    global vector_store, last_content_hash
    runbooks = fetch_runbooks()
    if not runbooks: return 0
    current_hash = hashlib.md5("".join([rb['title'] + rb['content'] for rb in runbooks]).encode()).hexdigest()
    if not force and last_content_hash == current_hash: return -1
    try:
        if vector_store: vector_store.delete_collection()
    except: pass
    documents = [Document(page_content=f"Title: {rb['title']}\n\nContent: {rb['content']}", metadata={"title": rb['title']}) for rb in runbooks]
    vector_store = Chroma.from_documents(documents=documents, embedding=OpenAIEmbeddings(model="text-embedding-3-small"), collection_name="runbooks", persist_directory=CHROMA_PATH)
    last_content_hash = current_hash
    return len(documents)

def auto_refresh_loop():
    while True:
        time.sleep(RAG_REFRESH_INTERVAL)
        try: refresh_embeddings()
        except: pass

def search_runbook(query):
    if vector_store is None: init_vector_store()
    try:
        results = vector_store.similarity_search_with_score(query, k=1)
        if results:
            doc, score = results[0]
            return {"title": doc.metadata.get("title"), "content": doc.page_content, "score": score}
    except: pass
    return None

def extract_command(content):
    match = re.search(r'Command:\s*(.+)', content)
    return match.group(1).strip() if match else None

def send_slack(alert_id, alert_name, container, command):
    if not hasattr(config, 'SLACK_WEBHOOK_URL') or config.SLACK_WEBHOOK_URL == "YOUR_SLACK_WEBHOOK_URL_HERE": return
    base_url = getattr(config, 'AGENT_PUBLIC_URL', 'http://localhost:5000')
    message = {"blocks": [
        {"type": "header", "text": {"type": "plain_text", "text": f"ALERT: {alert_name}"}},
        {"type": "section", "fields": [{"type": "mrkdwn", "text": f"*Container:*\n{container}"}, {"type": "mrkdwn", "text": f"*Time:*\n{datetime.now().strftime('%H:%M:%S')}"}]},
        {"type": "section", "text": {"type": "mrkdwn", "text": f"*Command:*\n`{command}`"}},
        {"type": "actions", "elements": [
            {"type": "button", "text": {"type": "plain_text", "text": "APPROVE"}, "style": "primary", "url": f"{base_url}/approve/{alert_id}"},
            {"type": "button", "text": {"type": "plain_text", "text": "REJECT"}, "style": "danger", "url": f"{base_url}/reject/{alert_id}"}
        ]}
    ]}
    try: requests.post(config.SLACK_WEBHOOK_URL, json=message)
    except: pass

def send_slack_result(alert_name, status):
    if not hasattr(config, 'SLACK_WEBHOOK_URL') or config.SLACK_WEBHOOK_URL == "YOUR_SLACK_WEBHOOK_URL_HERE": return
    try: requests.post(config.SLACK_WEBHOOK_URL, json={"attachments": [{"color": "#36a64f" if status == "success" else "#ff0000", "text": f"*{alert_name}* - {status.upper()}"}]})
    except: pass

def node_search(state: RemediationState) -> RemediationState:
    result = search_runbook(state['alert_name'])
    if result:
        command = extract_command(result['content'])
        print(f"[SEARCH] {result['title']} -> {command}")
        return {**state, "runbook_content": result['content'], "command": command or "", "status": "found" if command else "no_command"}
    print(f"[SEARCH] No runbook found")
    return {**state, "status": "no_runbook"}

def node_approval(state: RemediationState) -> RemediationState:
    alert_id = f"{state['alert_name']}_{state['container']}"
    pending_approvals[alert_id] = {"state": state, "approved": None}
    print(f"[APPROVAL] Waiting... /approve/{alert_id}")
    send_slack(alert_id, state['alert_name'], state['container'], state['command'])
    while pending_approvals[alert_id]["approved"] is None: time.sleep(1)
    approved = pending_approvals[alert_id]["approved"]
    del pending_approvals[alert_id]
    print(f"[APPROVAL] {'APPROVED' if approved else 'REJECTED'}")
    return {**state, "human_approved": approved, "status": "approved" if approved else "rejected"}

def node_execute(state: RemediationState) -> RemediationState:
    print(f"[EXECUTE] {state['command']}")
    subprocess.getoutput(state['command'])
    time.sleep(1)
    return {**state, "status": "executed"}

def node_verify(state: RemediationState) -> RemediationState:
    success = False
    if "httpd" in state['alert_name'].lower():
        success = bool(subprocess.getoutput('docker exec httpd-server pgrep -x httpd').strip())
    elif "cpu" in state['alert_name'].lower():
        try: success = float(subprocess.getoutput(f'docker stats {state["container"]} --no-stream --format "{{{{.CPUPerc}}}}"').replace('%', '')) < 50
        except: pass
    else: success = True
    print(f"[VERIFY] {'SUCCESS' if success else 'FAILED'}")
    if success: return {**state, "verified": True, "status": "success"}
    return {**state, "verified": False, "retry_count": state['retry_count'] + 1, "status": "verify_failed"}

def node_complete(state: RemediationState) -> RemediationState:
    print(f"[DONE] {state['status'].upper()}")
    send_slack_result(state['alert_name'], state['status'])
    return state

def route_search(state) -> Literal["approval", "complete"]:
    return "approval" if state["status"] == "found" else "complete"

def route_approval(state) -> Literal["execute", "complete"]:
    return "execute" if state["human_approved"] else "complete"

def route_verify(state) -> Literal["execute", "complete"]:
    if state["verified"]: return "complete"
    return "execute" if state["retry_count"] < MAX_RETRIES else "complete"

graph = StateGraph(RemediationState)
graph.add_node("search", node_search)
graph.add_node("approval", node_approval)
graph.add_node("execute", node_execute)
graph.add_node("verify", node_verify)
graph.add_node("complete", node_complete)
graph.set_entry_point("search")
graph.add_conditional_edges("search", route_search)
graph.add_conditional_edges("approval", route_approval)
graph.add_edge("execute", "verify")
graph.add_conditional_edges("verify", route_verify)
graph.add_edge("complete", END)
WORKFLOW = graph.compile(checkpointer=MemorySaver())

def process_alert(alert_name, container):
    print(f"\n[ALERT] {alert_name}")
    WORKFLOW.invoke({"alert_name": alert_name, "container": container, "runbook_content": "", "command": "", "human_approved": False, "verified": False, "retry_count": 0, "status": "started"}, {"configurable": {"thread_id": alert_name}})

@app.post("/webhook")
async def webhook(request: Request):
    data = await request.json()
    for alert in data.get('alerts', []):
        if alert.get('status') == 'firing':
            threading.Thread(target=process_alert, args=(alert['labels'].get('alertname', 'Unknown'), alert['labels'].get('container', '')), daemon=True).start()
    return {"status": "ok"}

@app.get("/approve/{alert_id}")
async def approve(alert_id: str):
    if alert_id in pending_approvals:
        pending_approvals[alert_id]["approved"] = True
        return {"status": "approved"}
    return {"status": "not_found"}

@app.get("/reject/{alert_id}")
async def reject(alert_id: str):
    if alert_id in pending_approvals:
        pending_approvals[alert_id]["approved"] = False
        return {"status": "rejected"}
    return {"status": "not_found"}

@app.get("/test")
async def test(type: str = "httpd"):
    alert = ("HTTPDServiceDown", "httpd-server") if type == "httpd" else ("HighCPU", "webserver")
    threading.Thread(target=process_alert, args=alert, daemon=True).start()
    return {"status": "triggered"}

if __name__ == "__main__":
    threading.Thread(target=start_exporter, daemon=True).start()
    subprocess.getoutput('docker exec httpd-server httpd -k start')
    init_vector_store()
    refresh_embeddings(force=True)
    threading.Thread(target=auto_refresh_loop, daemon=True).start()
    print("Agent Started")
    uvicorn.run(app, host="0.0.0.0", port=5000, log_level="error")

