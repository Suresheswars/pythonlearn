OPENAI_API_KEY = "sk-proj-Ua6VPyxhpnx5JX-5lPDi-dxZsP_zKeUa53GfHXQA"
DEFAULT_MODEL_OPENAI = "gpt-4o-mini"
CONFLUENCE_URL = "https://wetechzoneai.atlassian.net/wiki"
CONFLUENCE_USER = "management@wetechzone.com"
CONFLUENCE_TOKEN = "ATATT3xFfGF0UP1xmAKi7_YFA4IIPxtcEzS_HiTIq7BXhBuGedOps7kzApc3F_y21nYZKuuBXD5a3Q-Sp2qpm5Jes_izERzFWdBTAoW4g6769RhM0eOj7noQE6FepX39y8Pp1H7681oSe0QQ=6813B229"
CONFLUENCE_PARENT_PAGE_ID = "4423681"
SLACK_WEBHOOK_URL = "https://hooks.slack.com/serm2HkMpdG3fVvM"
AGENT_PUBLIC_URL = "http://localhost:5000"

