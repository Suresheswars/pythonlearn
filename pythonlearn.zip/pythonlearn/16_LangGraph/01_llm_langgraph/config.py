OPENAI_API_KEY = "sk-proj-IBu5T3BlbkFJhAe33rOE_qGG9-5lPDi-dxZsP_zKeUa53GfHXQA"
DEFAULT_MODEL_OPENAI = "gpt-4o-mini"
CONFLUENCE_URL = "https://wetechai.atlassian.net/wiki"
CONFLUENCE_USER = "management@wetechzone.com"
CONFLUENCE_TOKEN = "ATATT3xFfGF0UP1xmAKi7__izERzFWdBTAoW4g6j7noQE6FepX39y8Pp1H7681oSe0QQ=6813B229"
CONFLUENCE_PARENT_PAGE_ID = "442381"
SLACK_WEBHOOK_URL = "https://hooks.slack.com/serviMcm2HkMpdG3fVvM"
AGENT_PUBLIC_URL = "http://localhost:5000"

