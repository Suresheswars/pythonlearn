#Docker :


#Build a docker file nad run it :


import docker

client = docker.from_env()

print("Building image...")
image, logs = client.images.build(path=".", tag="myapp:latest")

for line in logs:
    if 'stream' in line:
        print(line['stream'].strip())

print("Running container...")
container = client.containers.run("myapp:latest", detach=True, ports={"80/tcp": 8080})

print(f"Container {container.name} is running on port 8080")


#####
#unused images :

import docker

client = docker.from_env()

print("Checking for unused docker images...\n")

used = {c.image.id for c in client.containers.list(all=True)}

removed = 0
for img in client.images.list():
    if img.id in used:
        continue

    tags = img.tags or ["<none>:<none>"]
    print(f"Removing unused image: {tags[0]} ({img.short_id})")

    try:
        client.images.remove(img.id, force=True)
        removed += 1
    except docker.errors.APIError as e:
        print(f"Could not remove {img.short_id}: {e}")

if removed == 0:
    print("\nNo unused images found.")
else:
    print(f"\nDone. Removed {removed} unused image(s).")


###



#create app.py

from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello():
    return 'Hello, World!'

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')




#cat requirements.txt
#Flask==3.1.2



#cat Dockerfile


FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .

EXPOSE 5000

CMD ["python3", "app.py"]




