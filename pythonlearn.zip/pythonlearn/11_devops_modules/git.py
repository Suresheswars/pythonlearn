import requests

GITHUB_USERNAME = 'sudarshanlnx'
GITHUB_TOKEN = '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'


url = f'https://api.github.com/users/{GITHUB_USERNAME}/repos'

headers = {
    'Authorization': f'token {GITHUB_TOKEN}',
    'Accept': 'application/vnd.github.v3+json'
}


response = requests.get(url, headers=headers)

if response.status_code == 200:
    repos = response.json()
    for repo in repos:
        print(repo['name'])
else:
    print(f'Failed to fetch repositories: {response.json()}')

###

#delete branch
#test
from github import Github
import os

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "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")
REPO_NAME = "sudarshanlnx/branchdemo"
EXCLUDE_BRANCHES = ["master", "main"]

g = Github(GITHUB_TOKEN)
repo = g.get_repo(REPO_NAME)

print(f"Checking all branches in {REPO_NAME}...\n")

for branch in repo.get_branches():
    branch_name = branch.name

    if branch_name in EXCLUDE_BRANCHES:
        print(f"Skipping protected branch: {branch_name}")
        continue

    print(f"Found branch: {branch_name}")
    try:
        ref = repo.get_git_ref(f"heads/{branch_name}")
        ref.delete()
        print(f"Deleted branch: {branch_name}")
    except Exception as e:
        print(f"Failed to delete branch {branch_name}: {e}")

print("\nCompleted branch cleanup.")


#git push origin --delete dev


#####