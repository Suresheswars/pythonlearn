Create instance using boto3

import boto3

ec2 = boto3.resource('ec2', region_name='us-west-2')

instances = ec2.create_instances(
    ImageId='ami-0404bac7d1d00727d',
    InstanceType='t2.micro',
    KeyName='saturn',
    SecurityGroups=['saturn-linux-sg'],
    MinCount=1,
    MaxCount=1,
    TagSpecifications=[{
        'ResourceType': 'instance',
        'Tags': [{'Key': 'Name', 'Value': 'ec2-python'}]
    }]
)

print(f'Instance created with ID: {instances[0].id}')



xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


#Terminate instance using boto3
import boto3

ec2 = boto3.resource('ec2', region_name='us-west-2')

instance_id = 'i-09960de49b4c47902'

instance = ec2.Instance(instance_id)
response = instance.terminate()

if response['ResponseMetadata']['HTTPStatusCode'] == 200:
    print(f"Instance {instance_id} terminated successfully.")
else:
    print(f"Failed to terminate instance {instance_id}.")


#How to stop instance :
import boto3

ec2 = boto3.client('ec2', region_name='us-west-2')

instance_id = 'i-0d418b23a1f87bb99'

ec2.stop_instances(InstanceIds=[instance_id])
print(f'Stopping instance {instance_id}')


#15 mins
import boto3
region = 'us-west-2'
instances = [‘i-00e2f701ecb8c6e79']
ec2 = boto3.client('ec2', region_name=region)

def lambda_handler(event, context):
    ec2.start_instances(InstanceIds=instances)
    print('started your instances: ' + str(instances))



xxxxxxxxxxxxx

#Start :

import boto3

ec2 = boto3.client('ec2', region_name='us-west-2')

instance_id = 'i-0e4a2917d76d584e7'

ec2.start_instances(InstanceIds=[instance_id])
print(f'Starting instance {instance_id}')



xxxxxxxxxxxxxxxxxxxxxxxxxxx

S3

#Delet old 10 days
import boto3, datetime

s3 = boto3.resource('s3')
bucket = s3.Bucket('jupiter-2024')

for obj in bucket.objects.all():
    if (datetime.datetime.now(datetime.timezone.utc) - obj.last_modified).days > 10:
        print(f"Deleting {obj.key}")
        obj.delete()



#Delete all buckets :

import boto3

s3 = boto3.resource('s3')
client = boto3.client('s3')

for bucket in s3.buckets.all():
    if bucket.name.startswith('cf'):
        print(f" Deleting bucket: {bucket.name}")


        try:
            bucket.objects.all().delete()
            bucket.object_versions.all().delete()

            bucket.delete()
            print(f" Bucket '{bucket.name}' deleted successfully.")
        except Exception as e:
            print(f" Failed to delete {bucket.name}: {e}")


##

5. unused volume

import boto3

def lambda_handler(event, context):

    ec2 = boto3.client('ec2', region_name='us-west-2')
    response = ec2.describe_volumes()

    for volume in response['Volumes']:
        if not volume['Attachments']:
            volume_id = volume['VolumeId']
            print(f'Deleting volume: {volume_id}')
            ec2.delete_volume(VolumeId=volume_id)

    return {
        'statusCode': 200,
        'body': 'Unused volumes cleaned up successfully'
    }



6. clearing snapshots

import boto3

def lambda_handler(event, context):

    ec2 = boto3.client('ec2', region_name='us-west-2')

    response = ec2.describe_snapshots(OwnerIds=['self'])


    for snapshot in response['Snapshots']:

        snapshot_id = snapshot['SnapshotId']
        print(f'Deleting snapshot: {snapshot_id}')
        ec2.delete_snapshot(SnapshotId=snapshot_id)

    return {
        'statusCode': 200,
        'body': 'All EC2 snapshots deleted successfully'
    }


