
#### multi function

def is_even(num):
    return num % 2 == 0

def square(num):
    return num ** 2

test = int(input("enter a number: "))

if is_even(test):
    print(f"{test} is even")
else:
    print(f"{test} is odd")

print(f"The square of {test} is {square(test)}")

