
def test(name):
    print("Hello", name)

test("Rajesh")
#########

def sum(a,b):
    c = a + b
    print(f"The sum is {c}")

sum(2, 4)

#######

try:
   def sum(a,b):
       return a+b

   print(sum(1, 4))
except Exception as err:
    print(err)

########