
def sum(a,b):
    c = a + b
    print("First_function_sum=", c)

def display(c):
    print(c)

d = sum(4, 4)

print("Second_function_sum=", display(d))

#############

def sum(a,b):
    return a + b

def display(c):
    return c

d = sum(4, 4)

print("Second_function_sum=", display(d))

########################

def even_odd(num):
    if num % 2 == 0:
        return "even"
    else:
        return "odd"

num = int(input("Enter the number:\n"))

result = even_odd(num)

print(num, "is", result)

###########

def even_odd(num):
    if num % 2 == 0:
        return "even"
    else:
        return "odd"

i = 0
while i < 3:
    num = int(input("Enter the number:\n"))

    result = even_odd(num)

    print(num, "is", result)

    i += 1
