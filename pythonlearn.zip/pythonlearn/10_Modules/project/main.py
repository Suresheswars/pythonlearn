import sys
sys.path.append("utils")

import helper
helper.greet()
###

from utils import helper

print(helper.greet("Hi this is using from"))