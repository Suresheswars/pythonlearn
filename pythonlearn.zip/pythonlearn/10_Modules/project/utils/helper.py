def greet():
    print("Hello from helper!")

###
def greet(message):
    return message