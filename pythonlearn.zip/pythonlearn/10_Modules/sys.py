import sys

print("All command line arguments:", sys.argv)

print("Python version is:", sys.version)

print("Platform is:", sys.platform)
###

import sys


if len(sys.argv) != 2:
    print("Invalid input! Please provide exactly one argument (dev or prod).")
    print("Example: python datatypes.py dev")
    sys.exit(1)


env = sys.argv[1].lower()


if env == "dev":
    print("Dev executed successfully!")
elif env == "prod":
    print("Prod executed successfully!")
else:
    print("Invalid environment name! Use 'dev' or 'prod'.")

######

def greet():
    print("Hello from helper!")

import sys
sys.path.append("utils")   # add custom folder to search path


import helper
helper.greet()

#####

def greet(message):
    return message

from utils import helper

print(helper.greet("Hi hello"))

######


