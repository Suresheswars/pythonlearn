import logging

logging.basicConfig(filename="app.log", level=logging.INFO)
logging.info("Script started successfully")
logging.warning("Low disk space warning")


#####


import logging

logging.basicConfig(filename="app.log", level=logging.INFO)

try:
    10 / 0
except Exception as e:
    logging.error(f"An error occurred: {e}")


####
