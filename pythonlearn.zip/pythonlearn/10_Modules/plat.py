
import platform

print("Operating System:", platform.system())
print("OS Version:", platform.version())
print("OS Release:", platform.release())
print("Architecture:", platform.architecture())
print("Machine:", platform.machine())
print("Processor:", platform.processor())
print("Python Version:", platform.python_version())
