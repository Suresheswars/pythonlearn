import requests

response = requests.get('https://www.google.com', timeout=5)

if response.status_code == 200:
    print("Google is avaiable")
else:
    print("not available")
##


import requests


try:
    response = requests.get('https://asdfadsfwww.google.com', timeout=5)

    if response.status_code == 200:
        print("Google is avaiable")
    else:
        print(f"Google returned a non-success code: {response.status_code}")

except requests.exceptions.RequestException as err:
    print(f"An error occurred: {err}")

##

#post

import requests

data = {"name": "devops-student", "role": "learner"}

response = requests.post("https://httpbin.org/post", json=data)

print("Status:", response.status_code)
print("Response JSON:", response.json())


####


