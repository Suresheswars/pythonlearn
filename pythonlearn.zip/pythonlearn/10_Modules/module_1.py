# Os module

# create a directory

# https://docs.python.org/3/library/os.html

import os
os.mkdir('/tmp/rajini')



# check file exists

import os

if os.path.exists('/opt'):
    print("exist")
else:
    print("no")




# List files in current directory


import os

files = os.listdir("/tmp")
print(files)

# (to list in order)

import os

for file in os.listdir("/tmp"):
    print(file)


# remove file :

import os

os.remove("/opt/python1")



# Installing multiple packages:


import os

commands = [
    "sudo yum install httpd -y",
    "sudo yum install java -y",
    "sudo yum install nanjuoo -y"
]

for i in commands:
    print(f"Executing: {i}")

    exit_code = os.system(i)

    print(f"executed with code: {exit_code}")




# Installing packages with file permission and copy file


import os

commands = [
    "sudo yum install httpd -y",
    "sudo yum install java -y",
    "sudo chmod 777 java.txt",
    "sudo cp java.txt /opt",
    "sudo yum install nanjuoo -y"
]

for i in commands:
    print(f"Executing: {i}")

    exit_code = os.system(i)

    print(f"executed with code: {exit_code}")




# Native file permissions:



import os

os.chmod("java.txt", 0o777)
