import json

data = {"name": "devops-student", "role": "learner"}
json_str = json.dumps(data, indent=2)
print(json_str)
