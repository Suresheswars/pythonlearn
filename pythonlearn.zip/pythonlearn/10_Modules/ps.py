import psutil

print("CPU Usage:", psutil.cpu_percent(interval=1), "%")
print("Memory Usage:", psutil.virtual_memory().percent, "%")

used_percent = psutil.disk_usage('/').percent
print(f"Disk usage for / : {used_percent} %")

for process in psutil.process_iter(['pid', 'name']):
    if 'nginx' in process.info['name']:
        print(f"Nginx is running with PID {process.info['pid']}")
        break
else:
    print("Nginx is not running")

####

import psutil

# 1. Network I/O
net = psutil.net_io_counters()
print(f"\n--- Network I/O ---")
print(f"Bytes Sent: {net.bytes_sent}")
print(f"Bytes Received: {net.bytes_recv}")

# 2. Network interfaces and IPs
print(f"\n--- Network Interfaces ---")
for iface, addrs in psutil.net_if_addrs().items():
    print(f"\nInterface: {iface}")
    for addr in addrs:
        print(f"  {addr.family.name if hasattr(addr.family, 'name') else addr.family} -> {addr.address}")

# 3. Interface stats
print(f"\n--- Interface Stats ---")
for iface, stats in psutil.net_if_stats().items():
    print(f"{iface}: Up={stats.isup}, Speed={stats.speed}Mbps, MTU={stats.mtu}")

# 4. Active connections (simplified)
print(f"\n--- Active Connections ---")
for conn in psutil.net_connections(kind='inet'):
    if conn.laddr:
        print(f"{conn.laddr.ip}:{conn.laddr.port} -> {conn.raddr.ip if conn.raddr else '-'} [{conn.status}] PID={conn.pid}")


###

