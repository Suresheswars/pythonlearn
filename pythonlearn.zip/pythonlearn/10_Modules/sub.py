
import subprocess

command = """
sudo yum install -y httpd &&
sudo mkdir -p /kamal
"""

subprocess.run(command, shell=True, check=True)


###

import os

os.system("systemctl restart nginx")

#####
#stderror
import subprocess

result = subprocess.run(["systemctl", "restart", "nginx"], capture_output=True, text=True)

if result.returncode == 0:
    print("Nginx restarted successfully!")
else:
    print(result.stderr)

#### stdout


import subprocess

servers = ["web01", "web02", "web03"]

for s in servers:
    result = subprocess.run(["ssh", s, "systemctl", "is-active", "nginx"], capture_output=True, text=True)
    if result.stdout.strip() != "active":
        print(f”Restarting Nginx on {s}")
        subprocess.run(["ssh", s, "sudo", "systemctl", "restart", "nginx"])

####

#security

import os

user = input("service: ")
os.system(f"systemctl restart {user}")


import subprocess
service = input("service: ").strip() #removes unwanted white spaces
subprocess.run(["systemctl", "restart", service])

