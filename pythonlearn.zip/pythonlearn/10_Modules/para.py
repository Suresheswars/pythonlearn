import paramiko

hostname = '172.31.30.96'
username = 'root'

client = paramiko.SSHClient()
client.load_system_host_keys()


try:
    client.connect(hostname, username=username)

    command = 'yum install -y httpd'

    stdin, stdout, stderr = client.exec_command(command)

    print(stdout.read().decode())
    print(stderr.read().decode())

finally:  #already error capture above
    stdin.close()  #for remote yes
    stdout.close()
    stderr.close()
    client.close()
###


import paramiko

hostname = '172.31.27.106'
username = 'root'

commands = [
    'mkdir -p /rajini',
    'touch /rajini/javafile1',
    'yum install -y java'
]

client = paramiko.SSHClient()
client.load_system_host_keys()


try:
    client.connect(hostname, username=username)

    for command in commands:
        stdin, stdout, stderr = client.exec_command(command)
        print(stdout.read().decode())
        print(stderr.read().decode())

finally:
    stdin.close()
    stdout.close()
    stderr.close()
    client.close()

####

###
multiple host:
hostname = ['172.31.27.106', '172.31.27.107', '172.31.27.108']
###