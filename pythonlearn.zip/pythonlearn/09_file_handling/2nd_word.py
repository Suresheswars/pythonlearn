with open('test.txt', 'r') as file:
    content = file.read()

count = 0
result = ""

for word in content.split('cricket'):
    result += word
    count += 1
    if count == 2:
        result += 'football'
    elif count < content.count('cricket') + 1:
        result += 'cricket'

with open('test.txt', 'w') as file:
    file.write(result)