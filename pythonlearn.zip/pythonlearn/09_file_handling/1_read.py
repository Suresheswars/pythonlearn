
file = open('test.txt', 'r')
content = file.read()
print(content)
file.close()


file = open('test.txt', 'r')
content = file.readline()
print(content)
file.close()

file = open('test.txt', 'r')
content = file.readlines()
print(content)
file.close()


file = open('test.txt', 'r')
content = [line.strip() for line in file]
print(content)
file.close()



#write

file = open('test.txt', 'w')
file.write("I like devops tools")

file = open('test.txt', 'r')
content = file.read()
print(content)
file.close()


#append

file = open('test.txt', 'a')
file.write("\nI like devops tools")
file.write("\nI like to play cricket")
file.close()

#

with open('test.txt', 'r') as file:
    content = file.read()
    print(content)
#

with open('test.txt', 'r') as file:
    lines = file.readlines()

lines[6] = lines[6].replace('football', 'Hockey')

with open('test.txt', 'w') as file:
    file.writelines(lines)
#

def delete_lines(file_path, start_line, end_line):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    del lines[start_line-1:end_line]

    with open(file_path, 'w') as file:
        file.writelines(lines)

delete_lines('test.txt', 3, 5)

#

#write file and read using with:

with open('output.txt', 'w+') as file:
    file.write("I also like chocolate")
    file.seek(0)
    contents = file.read()

print(contents)
####

#append and read:

with open('output.txt', 'a+') as file:
    file.write("\nI also like chocolate")
    file.write("\nI play cricket")
    file.seek(0)
    contents = file.read()

print(contents)
####


#replace and read:

with open('output.txt', 'r') as file:
    content = file.read()

modified_content = content.replace('like', 'love')

with open('output.txt', 'w+') as file:
    file.write(modified_content)
    file.seek(0)
    contents = file.read()
print(contents)
####

search='tools'

with open('test.txt', 'r') as file:
    for i in file:
        if search in i:
            print("available")
            break
    else:
        print("not available")






