#without constructor

class Car:
    def start(self):
        return f"{self.brand} car"

car1 = Car()
car1.brand = 'Tesla'

car2 = Car()
car2.brand = 'BMW'

print(car1.start())
print(car2.start())

#with constructor

class Car:
    def __init__(self, brand):
        self.brand = brand

    def start(self):
        return f"{self.brand} car"

car1 = Car("Tesla")
car2 = Car("BMW")

print(car1.start())
print(car2.start())

#multiple inputs:


class Car:
    def __init__(self, brand, color, year):
        self.brand = brand
        self.color = color
        self.year = year

    def start(self):
        return f"{self.brand}: {self.color}, {self.year} car"

car1 = Car("Tesla", "Red", 2022)
car2 = Car("BMW", "Black", 2023)
car3 = Car("Audi", "Blue", 2024)

print(car1.start())
print(car2.start())
print(car3.start())
