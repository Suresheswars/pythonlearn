class Car:
    country = "India"

    def __init__(self, brand, color, year):
        self.brand = brand
        self.color = color
        self.year = year

    def start(self):
        return f"{self.brand}: {self.color}, {self.year} car from {self.country}"

car1 = Car("Tesla", "Red", 2022)
car2 = Car("BMW", "Black", 2023)
car3 = Car("Audi", "Blue", 2024)

print(car1.start())
print(car2.start())
print(car3.start())