#
# def star_decorator(func):
#     def wrapper():
#         print("*" * 10)
#         func()
#         print("*" * 10)
#     return wrapper
#
# @star_decorator
# def greet():
#     print("Hello, Congrats")
#
# greet()
#
# #####
# def require_login(func):
#     def wrapper(user):
#         if user != "hemanth":
#             print("Access denied")
#             return
#         return func(user)
#     return wrapper
#
# @require_login
# def delete_server(user):
#     print(f"Server deleted by {user}")
#
# delete_server("guest")
# delete_server("hemanth")

def my_generator(n):
    value = 0
    while value < n:
        yield value  # Yield the current value
        value += 1

# Using the generator
for number in my_generator(5):
    print(number)