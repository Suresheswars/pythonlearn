#common character

class student:
    def sleep(self):
        return f"{self.name} is sleeping"


ravi = student()
ravi.name = "ravi"
ravi.age = 25

kumar = student()
kumar.name = "Kumar"
kumar.age = 26

print(f"{ravi.name}, {ravi.age}")
print(f"{kumar.name}, {kumar.age}")

print(ravi.sleep())
print(kumar.sleep())