
from abc import ABC, abstractmethod

class Bank(ABC):

    @abstractmethod
    def withdraw(self):
        print("The balance amount is 1000000")

    def enquiry(self):
        print("You have home loan")

class account(Bank):
    def withdraw(self):
        super().withdraw()
        print("Withdraw amount is 50000")

    def newenquiry(self):
        print("You have to pay back 10000 monthly")

bank1 = account()
bank1.withdraw()

bank1.enquiry()
bank1.newenquiry()

