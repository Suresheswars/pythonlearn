#
# class School:
#     def __init__(self):
#         self.Name = "sudarshan"
#         self.Place = "Chennai"
#         self.Revenue = "50000"
#
# school1 = School()
#
# print(school1.Name)
# print(school1.Place)
# print(school1.Revenue)
#
# class School:
#     def __init__(self):
#         self.Name = "sudarshan"
#         self.Place = "Chennai"
#         self._Revenue = "50000"
#
# class Faculty(School):
#     def Revenue(self):
#         print(self.Revenue)
#
# faculty = Faculty()
# print(faculty._Revenue)



class School:
    def __init__(self):
        self.Name = "sudarshan"
        self.Place = "Chennai"
        self.__Revenue = "50000"


school1 = School()


print(school1.Name)
print(school1.Place)
#print(school1.__Revenue)


print(school1._School__Revenue)



