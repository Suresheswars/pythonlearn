
class Grandparent:
    def Swim(self):
        print("I can SWIM")

class Parent:

    def __init__(self):
        self.networth = 10000000

    def Sing(self):
        print("I can sing")

class Child(Grandparent):
    def Dance(self):
        print("I can dance")

child1 = Child()
child1.Swim()

