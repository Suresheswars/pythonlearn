#Method Over loading

# class Person:
#     def __init__(self, name, age):
#         self.Name = name
#         self.Age = age
#
#     def working(self, workinghours):
#         print("Working duration is", workinghours)
#
#     def working(self, start, end):
#         print("Working time is", end - start)
#
#
# person1 = Person("Gokul", 22)
#
# print(person1.Name)
#
# person1.working(10, 18)




# class Person:
#     def __init__(self, name, age):
#         self.Name = name
#         self.Age = age
#
#     def working(self, workinghours = None, start = None, end = None):
#         if start is not None and end is not None:
#             print("Working duration is", end - start)
#         else:
#             print("Working time is", workinghours)
#
#
#
# person1 = Person("Gokul", 22)
# print(person1.Name)
#
# person1.working(15)
# person1.working(10, 9, 19)

#Method Overriding

# class Parent:
#     def Drive(self):
#         print("Parent is driving")
#
# class Child:
#     def Drive(self):
#         print("Child is driving")
#
# obj=None
#
# name = input()
# if name == "Parent":
#     obj = Parent()
# else:
#     obj = Child()

# obj.Drive()



#Operator Overloading

# class Student:
#     def __init__(self, marks):
#         self.marks = marks
#
# obj1 = Student(50)
# obj2 = Student(50)
#
# print(obj1 + obj2)


#
# class Student:
#     def __init__(self, marks):
#         self.marks = marks
#
#     def __add__(self, other):   #Operator overloading
#         return self.marks + other.marks
#
# obj1 = Student(50)
# obj2 = Student(50)
#
# print(obj1 + obj2)