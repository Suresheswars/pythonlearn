class Grandparent:
    def Swim(self):
        print("I can SWIM")

class Relative(Grandparent):
    def Drive(self):
        print("I can Drive")


class Parent(Grandparent):
    def __init__(self):
        self.networth = 10000000

    def Sing(self):
        print("I can sing")

class Child(Parent,Relative):
    def Dance(self):
        print("I can dance")


child1 = Child()
child1.Drive()
