class Parent:
    def Sing(self):
        print("I can sing")

class Child:
    def Dance(self):
        print("I can dance")

    def Sing(self):
        print("I can Sing")

child1 = Child()
child1.Sing()
#####


class Parent:
    def Sing(self):
        print("I can sing")

class Child(Parent):
    def Dance(self):
        print("I can dance")

child1 = Child()
child1.Sing()