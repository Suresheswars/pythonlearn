
def student(name):
    return name

def age(age):
    return age

print(f"{student('vinoth')}, {age(22)}")

#####

class student:
    pass

ravi = student()
ravi.name = "ravi"
ravi.age = 25

kumar = student()
kumar.name = "Kumar"
kumar.age = 26

print(f"{ravi.name}, {ravi.age}")
print(f"{kumar.name}, {kumar.age}")

