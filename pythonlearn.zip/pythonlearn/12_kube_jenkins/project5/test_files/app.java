

package com.example.app;

public class DatabaseConfig {
    // Hardcoded database credentials
    private static final String DB_USERNAME = "admin";
    private static final String DB_PASSWORD = "Admin@12345";
    private static final String DB_URL = "mysql://admin:password@prod-db.example.com:3306/production";
    
    // AWS credentials
    private static final String AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE";
    private static final String AWS_SECRET = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";
    
    // API keys
    private static final String STRIPE_KEY = "sk_live_51234567890abcdefg";
    private static final String SENDGRID_API_KEY = "SG.1234567890abcdefghijklmnopqrstuvwxyz";
    
    // JWT Secret
    private static final String JWT_SECRET = "my-jwt-secret-key-do-not-share";
    
    public String getPassword() {
        return "hardcoded_password_123";
    }
}

