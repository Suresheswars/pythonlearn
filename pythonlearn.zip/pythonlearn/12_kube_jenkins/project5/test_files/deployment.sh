#!/bin/bash

# AWS credentials in script
export AWS_ACCESS_KEY_ID="AKIAI44QH8DHBEXAMPLE"
export AWS_SECRET_ACCESS_KEY="je7MtGbClwBF/2Zp9Utk/h3yCo8nvbEXAMPLEKEY"

# Docker Hub credentials
docker login -u myusername -p MyDockerPassword123!

# Database credentials
mysql -u root -p"RootPassword123" -h database.example.com

# GitHub token
git clone https://ghp_1234567890abcdefghijklmnopqrstuv@github.com/user/repo.git

# SSH Key (partial for demo)
echo "-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA1234567890abcdefghijklmnop
-----END RSA PRIVATE KEY-----" > ~/.ssh/id_rsa

# Slack webhook
curl -X POST https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXX \
  -d '{"text":"Deploy complete"}'

