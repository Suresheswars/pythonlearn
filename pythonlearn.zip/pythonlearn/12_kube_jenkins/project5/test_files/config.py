
# AWS Credentials exposed
aws_access_key = "AKIAIOSFODNN7EXAMPLE"
aws_secret_key = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

# Database credentials
db_host = "database.example.com"
db_user = "admin"
db_password = "SuperSecret123!"

# API Keys exposed
api_key = "sk_live_1234567890abcdefghijklmnopqrstuvwxyz"
stripe_api_key = "sk_test_4eC39HqLyjWDarjtT1zdp7dc"

# Database connection string
DATABASE_URL = "postgres://username:password123@localhost:5432/mydb"

# Hardcoded secrets
SECRET_KEY = "django-insecure-$#^&*()_+1234567890abcdefg"
JWT_SECRET = "my-super-secret-jwt-key-12345"

# Another password
admin_password = "admin123"
root_password = "P@ssw0rd!"

def connect_to_service():
    # BAD: Hardcoded bearer token
    token = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
    return token

