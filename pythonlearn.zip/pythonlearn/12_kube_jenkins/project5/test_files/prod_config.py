# GOOD EXAMPLE

import os

# Get credentials from environment variables
aws_access_key = os.getenv('AWS_ACCESS_KEY_ID')
aws_secret_key = os.getenv('AWS_SECRET_ACCESS_KEY')

# Database credentials from environment
db_host = os.getenv('DB_HOST')
db_user = os.getenv('DB_USER')
db_password = os.getenv('DB_PASSWORD')

# API Keys from environment
api_key = os.getenv('API_KEY')
stripe_api_key = os.getenv('STRIPE_API_KEY')

# Database connection from environment
DATABASE_URL = os.getenv('DATABASE_URL')

# Secret key from environment
SECRET_KEY = os.getenv('SECRET_KEY')
JWT_SECRET = os.getenv('JWT_SECRET')

# Good practice: Use configuration management
# - AWS Secrets Manager
# - HashiCorp Vault
# - Kubernetes Secrets
# - Azure Key Vault

print("✅ This file is secure - no hardcoded secrets!")

