import re
import os
import sys

if len(sys.argv) < 2:
    print("Usage: python3 security_scanner.py <directory>")
    print("Example: python3 security_scanner.py .")
    sys.exit(1)

scan_dir = sys.argv[1]

print("="*60)
print("SECURITY SCANNER - SECRET DETECTION")
print("="*60)
print(f"Scanning directory: {scan_dir}")
print("="*60)

# Patterns to detect
patterns = {
    'AWS Access Key': r'AKIA[0-9A-Z]{16}',
    'AWS Secret Key': r'aws_secret[_\s]*[:=][_\s]*["\']([0-9a-zA-Z/+=]{40})["\']',
    'Generic Secret': r'secret[_\s]*[:=][_\s]*["\']([^"\']{8,})["\']',
    'Password': r'password[_\s]*[:=][_\s]*["\']([^"\']+)["\']',
    'API Key': r'api[_\s]*key[_\s]*[:=][_\s]*["\']([^"\']+)["\']',
    'Private Key': r'-----BEGIN (RSA |DSA |EC |OPENSSH )?PRIVATE KEY-----',
    'Database URL': r'(mysql|postgres|mongodb):\/\/[^\s]+',
    'Bearer Token': r'Bearer\s+[A-Za-z0-9\-._~+\/]+',
    'GitHub Token': r'gh[pousr]_[A-Za-z0-9]{36}',
    'Slack Token': r'xox[baprs]-[0-9]{10,12}-[0-9]{10,12}-[a-zA-Z0-9]{24,32}'
}

# Files to skip
skip_extensions = ['.git', '.pyc', '.jpg', '.png', '.pdf', '.zip']
skip_files = ['security_scanner.py', '.gitignore']

findings = []
files_scanned = 0

# Scan files
for root, dirs, files in os.walk(scan_dir):
    # Skip .git directory
    dirs[:] = [d for d in dirs if d not in ['.git', 'node_modules', '__pycache__']]
    
    for file in files:
        # Skip certain files
        if file in skip_files:
            continue
        
        # Skip certain extensions
        if any(file.endswith(ext) for ext in skip_extensions):
            continue
        
        filepath = os.path.join(root, file)
        
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                files_scanned += 1
                
                for line_num, line in enumerate(lines, 1):
                    for secret_type, pattern in patterns.items():
                        matches = re.finditer(pattern, line, re.IGNORECASE)
                        for match in matches:
                            findings.append({
                                'type': secret_type,
                                'file': filepath,
                                'line': line_num,
                                'content': line.strip(),
                                'match': match.group(0)
                            })
        except Exception as e:
            pass  # Skip files that can't be read

# Display results
print(f"\nFiles scanned: {files_scanned}")
print(f"Security issues found: {len(findings)}")

if findings:
    print("\n" + "="*60)
    print("SECURITY ISSUES DETECTED")
    print("="*60)
    
    # Group by severity
    critical = []
    high = []
    medium = []
    
    for finding in findings:
        if finding['type'] in ['AWS Access Key', 'AWS Secret Key', 'Private Key', 'GitHub Token']:
            critical.append(finding)
        elif finding['type'] in ['Password', 'API Key', 'Database URL', 'Bearer Token']:
            high.append(finding)
        else:
            medium.append(finding)
    
    # Show Critical
    if critical:
        print(f"\n[CRITICAL] {len(critical)} Critical Issues:")
        for finding in critical:
            print(f"\n  Type: {finding['type']}")
            print(f"  File: {finding['file']}")
            print(f"  Line: {finding['line']}")
            print(f"  Found: {finding['match'][:50]}...")
    
    # Show High
    if high:
        print(f"\n[HIGH] {len(high)} High Severity Issues:")
        for finding in high:
            print(f"\n  Type: {finding['type']}")
            print(f"  File: {finding['file']}")
            print(f"  Line: {finding['line']}")
            print(f"  Content: {finding['content'][:60]}...")
    
    # Show Medium
    if medium:
        print(f"\n[MEDIUM] {len(medium)} Medium Severity Issues:")
        for finding in medium:
            print(f"\n  Type: {finding['type']}")
            print(f"  File: {finding['file']}")
            print(f"  Line: {finding['line']}")
    
    # Summary by type
    print("\n" + "="*60)
    print("SUMMARY BY TYPE")
    print("="*60)
    
    type_counts = {}
    for finding in findings:
        type_counts[finding['type']] = type_counts.get(finding['type'], 0) + 1
    
    for secret_type, count in sorted(type_counts.items(), key=lambda x: x[1], reverse=True):
        print(f"  {secret_type}: {count}")
    
    print("\n" + "="*60)
    print("RECOMMENDATION: Remove all hardcoded secrets!")
    print("Use environment variables or secret management tools.")
    print("="*60)
    
else:
    print("\n✅ No security issues found!")
    print("All files are clean.")

