from kubernetes import client, config
import sys

if len(sys.argv) < 2:
    print("Usage: python3 k8s_health_monitor.py <namespace>")
    print("Example: python3 k8s_health_monitor.py default")
    print("Use 'all' to check all namespaces")
    sys.exit(1)

namespace = sys.argv[1]

print("="*60)
print("KUBERNETES HEALTH MONITOR")
print("="*60)
print(f"Cluster: devcluster")
print(f"Namespace: {namespace}")
print("="*60)

# Load kubeconfig
try:
    config.load_kube_config()
except:
    config.load_incluster_config()

v1 = client.CoreV1Api()
metrics_api = client.CustomObjectsApi()

# Get namespaces to check
if namespace == 'all':
    namespaces = [ns.metadata.name for ns in v1.list_namespace().items]
else:
    namespaces = [namespace]

# 1. Pod Health Check
print("\n[1] Pod Health Status:")
unhealthy_count = 0
high_restart_count = 0
total_pods = 0

for ns in namespaces:
    try:
        pods = v1.list_namespaced_pod(ns)
        
        for pod in pods.items:
            total_pods += 1
            pod_name = pod.metadata.name
            pod_status = pod.status.phase
            
            # Check container statuses
            if pod.status.container_statuses:
                for container in pod.status.container_statuses:
                    restart_count = container.restart_count
                    
                    # Check for high restarts
                    if restart_count > 5:
                        print(f"  [HIGH RESTARTS] {pod_name} ({ns})")
                        print(f"    Restarts: {restart_count}")
                        print(f"    Status: {pod_status}")
                        print()
                        high_restart_count += 1
                    
                    # Check for unhealthy states
                    if container.state.waiting:
                        reason = container.state.waiting.reason
                        if reason in ['CrashLoopBackOff', 'ImagePullBackOff', 'ErrImagePull']:
                            print(f"  [UNHEALTHY] {pod_name} ({ns})")
                            print(f"    Container: {container.name}")
                            print(f"    Reason: {reason}")
                            print(f"    Status: {pod_status}")
                            print()
                            unhealthy_count += 1
            
            # Check pod phase
            if pod_status in ['Pending', 'Failed', 'Unknown']:
                print(f"  [ISSUE] {pod_name} ({ns})")
                print(f"    Status: {pod_status}")
                print()
                unhealthy_count += 1
    except Exception as e:
        print(f"  Error checking namespace {ns}: {str(e)}")

if unhealthy_count == 0 and high_restart_count == 0:
    print("  All pods are healthy!")

print(f"Total pods checked: {total_pods}")
print(f"Unhealthy pods: {unhealthy_count}")
print(f"Pods with high restarts: {high_restart_count}")

# 2. Pod Resource Usage
print("\n" + "="*60)
print("[2] Pod Resource Utilization:")
underutilized_count = 0

# Get metrics from metrics-server
try:
    for ns in namespaces:
        try:
            pods = v1.list_namespaced_pod(ns)
            
            # Try to get pod metrics
            try:
                pod_metrics = metrics_api.list_namespaced_custom_object(
                    group="metrics.k8s.io",
                    version="v1beta1",
                    namespace=ns,
                    plural="pods"
                )
                
                # Create a dict of pod metrics for easy lookup
                metrics_dict = {}
                for item in pod_metrics.get('items', []):
                    pod_name = item['metadata']['name']
                    metrics_dict[pod_name] = item
            except:
                metrics_dict = {}
            
            for pod in pods.items:
                pod_name = pod.metadata.name
                
                if pod.spec.containers and pod.status.phase == 'Running':
                    for container in pod.spec.containers:
                        if container.resources and container.resources.requests:
                            cpu_request = container.resources.requests.get('cpu', 'Not set')
                            memory_request = container.resources.requests.get('memory', 'Not set')
                            
                            if cpu_request != 'Not set' and memory_request != 'Not set':
                                print(f"  Pod: {pod_name} ({ns})")
                                print(f"    CPU Request: {cpu_request}")
                                print(f"    Memory Request: {memory_request}")
                                
                                # Try to get actual usage
                                if pod_name in metrics_dict:
                                    containers_metrics = metrics_dict[pod_name].get('containers', [])
                                    for cont_metric in containers_metrics:
                                        if cont_metric['name'] == container.name:
                                            cpu_usage = cont_metric['usage'].get('cpu', '0')
                                            memory_usage = cont_metric['usage'].get('memory', '0')
                                            
                                            # Convert and calculate percentage
                                            try:
                                                # Simple conversion for demo
                                                cpu_usage_val = int(cpu_usage.replace('n', '')) / 1000000 if 'n' in cpu_usage else int(cpu_usage.replace('m', ''))
                                                cpu_request_val = int(cpu_request.replace('m', ''))
                                                cpu_percent = (cpu_usage_val / cpu_request_val) * 100 if cpu_request_val > 0 else 0
                                                
                                                memory_usage_val = int(memory_usage.replace('Ki', ''))
                                                memory_request_val = int(memory_request.replace('Mi', '')) * 1024
                                                memory_percent = (memory_usage_val / memory_request_val) * 100 if memory_request_val > 0 else 0
                                                
                                                print(f"    CPU Usage: {cpu_percent:.1f}%")
                                                print(f"    Memory Usage: {memory_percent:.1f}%")
                                                
                                                # Flag underutilized resources separately
                                                status_messages = []
                                                if cpu_percent < 20:
                                                    status_messages.append("CPU UNDERUTILIZED (<20%)")
                                                    underutilized_count += 1
                                                if memory_percent < 20:
                                                    status_messages.append("Memory UNDERUTILIZED (<20%)")
                                                
                                                if cpu_percent > 80:
                                                    status_messages.append("CPU HIGH USAGE (>80%)")
                                                if memory_percent > 80:
                                                    status_messages.append("Memory HIGH USAGE (>80%)")
                                                
                                                if status_messages:
                                                    print(f"    Status: {', '.join(status_messages)}")
                                            except:
                                                print(f"    Usage: Unable to calculate")
                                else:
                                    print(f"    Usage: Metrics not available")
                                
                                print()
        except Exception as e:
            print(f"  Error checking resources in {ns}: {str(e)}")
except Exception as e:
    print(f"  Note: Metrics server might not be installed. Showing requests only.")
    print(f"  Install metrics-server to see actual usage percentages.")

# 3. Unused PVCs
print("\n" + "="*60)
print("[3] Persistent Volume Claims:")
unused_pvc_count = 0
total_pvc_count = 0

for ns in namespaces:
    try:
        pvcs = v1.list_namespaced_persistent_volume_claim(ns)
        pods = v1.list_namespaced_pod(ns)
        
        # Get all PVCs used by pods
        used_pvcs = set()
        for pod in pods.items:
            if pod.spec.volumes:
                for volume in pod.spec.volumes:
                    if volume.persistent_volume_claim:
                        used_pvcs.add(volume.persistent_volume_claim.claim_name)
        
        # Check each PVC
        for pvc in pvcs.items:
            total_pvc_count += 1
            pvc_name = pvc.metadata.name
            pvc_size = pvc.spec.resources.requests.get('storage', 'Unknown')
            pvc_status = pvc.status.phase
            
            if pvc_name not in used_pvcs:
                print(f"  [UNUSED] {pvc_name} ({ns})")
                print(f"    Size: {pvc_size}")
                print(f"    Status: {pvc_status}")
                print()
                unused_pvc_count += 1
    except Exception as e:
        print(f"  Error checking PVCs in {ns}: {str(e)}")

if unused_pvc_count == 0:
    print("  No unused PVCs found")

print(f"Total PVCs: {total_pvc_count}")
print(f"Unused PVCs: {unused_pvc_count}")

# 4. Node Status
print("\n" + "="*60)
print("[4] Node Health:")
try:
    nodes = v1.list_node()
    
    for node in nodes.items:
        node_name = node.metadata.name
        
        # Check node conditions
        ready = False
        for condition in node.status.conditions:
            if condition.type == 'Ready':
                ready = condition.status == 'True'
                break
        
        if not ready:
            print(f"  [NOT READY] {node_name}")
        else:
            # Show node info
            cpu_capacity = node.status.capacity.get('cpu', 'Unknown')
            memory_capacity = node.status.capacity.get('memory', 'Unknown')
            
            print(f"  Node: {node_name}")
            print(f"    Status: Ready")
            print(f"    CPU: {cpu_capacity}")
            print(f"    Memory: {memory_capacity}")
            print()
    
    print(f"Total nodes: {len(nodes.items)}")
except Exception as e:
    print(f"  Error checking nodes: {str(e)}")

# Summary
print("\n" + "="*60)
print("SUMMARY")
print("="*60)
print(f"Cluster: devcluster")
print(f"Total Pods: {total_pods}")
print(f"Unhealthy Pods: {unhealthy_count}")
print(f"High Restart Pods: {high_restart_count}")
print(f"Total PVCs: {total_pvc_count}")
print(f"Unused PVCs: {unused_pvc_count}")
print(f"Nodes: {len(nodes.items) if 'nodes' in locals() else 'N/A'}")
print("="*60)

