import boto3
import sys
from datetime import datetime, timedelta, timezone

if len(sys.argv) < 2:
    print("Usage: python3 aws_cost_analyzer.py <region>")
    print("Example: python3 aws_cost_analyzer.py us-west-2")
    sys.exit(1)

region = sys.argv[1]

print("="*60)
print("AWS RESOURCE ANALYZER")
print("="*60)
print(f"Region: {region}")
print("="*60)

ec2 = boto3.client('ec2', region_name=region)
elb = boto3.client('elbv2', region_name=region)
s3 = boto3.client('s3', region_name=region)
rds = boto3.client('rds', region_name=region)
efs = boto3.client('efs', region_name=region)
route53 = boto3.client('route53')

#  Unused EBS Volumes
print("\n[1] Unused EBS Volumes:")
volumes = ec2.describe_volumes()['Volumes']

unused_count = 0
for volume in volumes:
    if len(volume['Attachments']) == 0 and volume['State'] == 'available':
        print(f"  Volume ID: {volume['VolumeId']}")
        print(f"  Size: {volume['Size']} GB")
        print(f"  State: {volume['State']}")
        print()
        unused_count += 1

if unused_count == 0:
    print("  No unused volumes found")

print(f"Total unused volumes: {unused_count}")

#  Stopped EC2 Instances
print("\n" + "="*60)
print("[2] Stopped EC2 Instances:")
instances = ec2.describe_instances()

stopped_count = 0
for reservation in instances['Reservations']:
    for instance in reservation['Instances']:
        if instance['State']['Name'] == 'stopped':
            print(f"  Instance ID: {instance['InstanceId']}")
            print(f"  Type: {instance['InstanceType']}")
            print(f"  State: {instance['State']['Name']}")
            print(f"  Launch Time: {instance['LaunchTime'].strftime('%Y-%m-%d %H:%M')}")
            print()
            stopped_count += 1

if stopped_count == 0:
    print("  No stopped instances found")

print(f"Total stopped instances: {stopped_count}")

#  Old Snapshots (>5 days)
print("\n" + "="*60)
print("[3] Snapshots (older than 5 days):")
snapshots = ec2.describe_snapshots(OwnerIds=['self'])['Snapshots']

cutoff_date = datetime.now(timezone.utc) - timedelta(days=5)
old_snapshot_count = 0

for snapshot in snapshots:
    if snapshot['StartTime'] < cutoff_date:
        age_days = (datetime.now(timezone.utc) - snapshot['StartTime']).days
        print(f"  Snapshot ID: {snapshot['SnapshotId']}")
        print(f"  Size: {snapshot['VolumeSize']} GB")
        print(f"  Created: {snapshot['StartTime'].strftime('%Y-%m-%d')}")
        print(f"  Age: {age_days} days")
        print()
        old_snapshot_count += 1

if old_snapshot_count == 0:
    print("  No old snapshots found")

print(f"Total old snapshots: {old_snapshot_count}")

#  Load Balancers
print("\n" + "="*60)
print("[4] Load Balancers:")
try:
    load_balancers = elb.describe_load_balancers()['LoadBalancers']
    
    lb_count = len(load_balancers)
    for lb in load_balancers:
        print(f"  Name: {lb['LoadBalancerName']}")
        print(f"  Type: {lb['Type']}")
        print(f"  State: {lb['State']['Code']}")
        print(f"  DNS: {lb['DNSName']}")
        print()
    
    if lb_count == 0:
        print("  No load balancers found")
    
    print(f"Total load balancers: {lb_count}")
except Exception as e:
    print(f"  Error checking load balancers: {str(e)}")

#  S3 Buckets
print("\n" + "="*60)
print("[5] S3 Buckets:")
try:
    buckets = s3.list_buckets()['Buckets']
    cutoff_date = datetime.now(timezone.utc) - timedelta(days=90)
    
    buckets_with_old_objects = 0
    
    for bucket in buckets:
        bucket_name = bucket['Name']
        bucket_creation = bucket['CreationDate'].strftime('%Y-%m-%d')
        
        try:
            objects = s3.list_objects_v2(Bucket=bucket_name, MaxKeys=100)
            
            if 'Contents' in objects:
                old_objects = [obj for obj in objects['Contents'] if obj['LastModified'] < cutoff_date]
                total_objects = len(objects['Contents'])
                
                # Only print if bucket has old objects
                if old_objects:
                    print(f"  Bucket: {bucket_name}")
                    print(f"  Created: {bucket_creation}")
                    print(f"  Total objects: {total_objects}")
                    print(f"  Old objects (>90 days): {len(old_objects)}")
                    print()
                    buckets_with_old_objects += 1
        except Exception as e:
            pass  # Skip buckets we can't access
    
    print(f"Total S3 buckets: {len(buckets)}")
    print(f"Buckets with old objects: {buckets_with_old_objects}")
except Exception as e:
    print(f"  Error checking S3: {str(e)}")

#  RDS Snapshots older than 2 days
print("\n" + "="*60)
print("[6] RDS Snapshots (older than 2 days):")
try:
    rds_snapshots = rds.describe_db_snapshots()['DBSnapshots']
    cutoff_date = datetime.now(timezone.utc) - timedelta(days=2)
    
    old_rds_count = 0
    for snapshot in rds_snapshots:
        if snapshot['SnapshotCreateTime'] < cutoff_date:
            age_days = (datetime.now(timezone.utc) - snapshot['SnapshotCreateTime']).days
            print(f"  Snapshot ID: {snapshot['DBSnapshotIdentifier']}")
            print(f"  DB Instance: {snapshot.get('DBInstanceIdentifier', 'N/A')}")
            print(f"  Created: {snapshot['SnapshotCreateTime'].strftime('%Y-%m-%d')}")
            print(f"  Age: {age_days} days")
            print()
            old_rds_count += 1
    
    if old_rds_count == 0:
        print("  No old RDS snapshots found")
    
    print(f"Total old RDS snapshots: {old_rds_count}")
except Exception as e:
    print(f"  Error checking RDS snapshots: {str(e)}")

#  EFS File Systems
print("\n" + "="*60)
print("[7] EFS File Systems:")
try:
    file_systems = efs.describe_file_systems()['FileSystems']
    
    efs_count = len(file_systems)
    for fs in file_systems:
        print(f"  File System ID: {fs['FileSystemId']}")
        print(f"  Name: {fs.get('Name', 'N/A')}")
        print(f"  Size: {fs['SizeInBytes']['Value'] / (1024**3):.2f} GB")
        print(f"  State: {fs['LifeCycleState']}")
        print()
    
    if efs_count == 0:
        print("  No EFS file systems found")
    
    print(f"Total EFS file systems: {efs_count}")
except Exception as e:
    print(f"  Error checking EFS: {str(e)}")

#  Route 53 Hosted Zones
print("\n" + "="*60)
print("[8] Route 53 Hosted Zones:")
try:
    hosted_zones = route53.list_hosted_zones()['HostedZones']
    
    zone_count = len(hosted_zones)
    for zone in hosted_zones:
        zone_id = zone['Id'].split('/')[-1]
        print(f"  Zone ID: {zone_id}")
        print(f"  Name: {zone['Name']}")
        print(f"  Private: {zone.get('Config', {}).get('PrivateZone', False)}")
        
        # Count records
        try:
            records = route53.list_resource_record_sets(HostedZoneId=zone['Id'])
            record_count = len(records['ResourceRecordSets'])
            print(f"  DNS Records: {record_count}")
        except:
            print(f"  DNS Records: Unable to fetch")
        print()
    
    if zone_count == 0:
        print("  No Route 53 hosted zones found")
    
    print(f"Total hosted zones: {zone_count}")
except Exception as e:
    print(f"  Error checking Route 53: {str(e)}")

# Summary
print("\n" + "="*60)
print("SUMMARY")
print("="*60)
print(f"Region: {region}")
print(f"Unused EBS Volumes: {unused_count}")
print(f"Stopped EC2 Instances: {stopped_count}")
print(f"Old EBS Snapshots (>5 days): {old_snapshot_count}")
print(f"Load Balancers: {lb_count if 'lb_count' in locals() else 'N/A'}")
print(f"S3 Buckets: {len(buckets) if 'buckets' in locals() else 'N/A'}")
print(f"Old RDS Snapshots (>2 days): {old_rds_count if 'old_rds_count' in locals() else 'N/A'}")
print(f"EFS File Systems: {efs_count if 'efs_count' in locals() else 'N/A'}")
print(f"Route 53 Hosted Zones: {zone_count if 'zone_count' in locals() else 'N/A'}")
print("="*60)
