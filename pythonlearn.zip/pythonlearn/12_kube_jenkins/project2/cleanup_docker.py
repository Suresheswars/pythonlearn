import requests
import sys
import os
from datetime import datetime, timedelta

if len(sys.argv) < 3:
    print("Usage: python3 cleanup_docker.py <username/repository> <days>")
    print("Example: python3 cleanup_docker.py sudarshanlnx/jaguarweb1 20")
    sys.exit(1)


repository = sys.argv[1]
username, repo_name = repository.split('/')
days_old = int(sys.argv[2])


docker_user = os.getenv('DOCKER_USERNAME')
docker_pass = os.getenv('DOCKER_PASSWORD')

print("="*60)
print("DOCKER HUB IMAGE CLEANUP")
print("="*60)
print(f"Repository: {repository}")
print(f"Delete images older than: {days_old} days")
print("="*60)

#  Login to Docker Hub
print("\n[1] Logging into Docker Hub...")
print(f"Username: {docker_user}")
login_url = "https://hub.docker.com/v2/users/login"
login_data = {"username": docker_user, "password": docker_pass}
response = requests.post(login_url, json=login_data)

if response.status_code != 200:
    print(f"[ERROR] Login failed!")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.text}")
    sys.exit(1)

token = response.json()['token']
print("[SUCCESS] Logged in successfully")

#  Get all tags
print(f"\n[2] Fetching tags from {repository}...")
tags_url = f"https://hub.docker.com/v2/repositories/{username}/{repo_name}/tags"
headers = {"Authorization": f"Bearer {token}"}
response = requests.get(tags_url, headers=headers)

if response.status_code != 200:
    print("[ERROR] Failed to fetch tags!")
    sys.exit(1)

tags = response.json()['results']
print(f"[SUCCESS] Found {len(tags)} tags")

# Step 3: Delete old tags
print(f"\n[3] Deleting old tags...")
cutoff_date = datetime.now() - timedelta(days=days_old)
print(f"Cutoff date: {cutoff_date.strftime('%Y-%m-%d')}")
print()

protected_tags = ['latest', 'stable', 'production', 'prod']
deleted_count = 0
kept_count = 0

for tag in tags:
    tag_name = tag['name']
    last_updated = tag['last_updated']
    
    # Parse date
    try:
        tag_date = datetime.strptime(last_updated.split('.')[0], '%Y-%m-%dT%H:%M:%S')
    except:
        tag_date = datetime.strptime(last_updated, '%Y-%m-%dT%H:%M:%SZ')
    
    age_days = (datetime.now() - tag_date).days
    
    # Check if protected
    if tag_name in protected_tags:
        print(f"[PROTECTED] {tag_name} (age: {age_days} days)")
        kept_count += 1
        continue
    
    # Check if old enough to delete
    if tag_date < cutoff_date:
        print(f"[OLD] {tag_name} (age: {age_days} days)", end='')
        
        # Delete the tag
        delete_url = f"https://hub.docker.com/v2/repositories/{username}/{repo_name}/tags/{tag_name}/"
        del_response = requests.delete(delete_url, headers=headers)
        
        if del_response.status_code == 204:
            print(" - DELETED")
            deleted_count += 1
        else:
            print(f" - FAILED (Status: {del_response.status_code})")
            print(f"    Error: {del_response.text}")
    else:
        print(f"[KEEP] {tag_name} (age: {age_days} days) - Too recent")
        kept_count += 1

# Summary
print()
print("="*60)
print("SUMMARY")
print("="*60)
print(f"Total tags: {len(tags)}")
print(f"Deleted: {deleted_count}")
print(f"Kept: {kept_count}")
print("="*60)
