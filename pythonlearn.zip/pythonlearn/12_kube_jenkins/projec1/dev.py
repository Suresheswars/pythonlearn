import paramiko
import sys

if len(sys.argv) < 2:
    print("Usage: python3 dev.py <ip_address>")
    sys.exit(1)

target_ip = sys.argv[1]

print("="*50)
print("DEV ENVIRONMENT DEPLOYMENT")
print(f"Target IP: {target_ip}")
print("="*50)

# Connect to target server
print(f"\nConnecting to {target_ip}...")
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(target_ip, username='jenkinsadm', look_for_keys=True, allow_agent=True)
print("Connected successfully!")

# Check and install httpd
print("\n[1] Checking httpd...")
stdin, stdout, stderr = ssh.exec_command('rpm -q httpd')
exit_code = stdout.channel.recv_exit_status()

if exit_code == 0:
    print("[INFO] httpd is already installed")
else:
    print("[INFO] httpd not found. Installing...")
    stdin, stdout, stderr = ssh.exec_command('sudo yum install -y httpd')
    stdout.channel.recv_exit_status()
    print("[SUCCESS] httpd installed successfully")

# Check and create folder
print("\n[2] Checking folder /opt/app_data...")
stdin, stdout, stderr = ssh.exec_command('test -d /opt/app_data')
exit_code = stdout.channel.recv_exit_status()

if exit_code == 0:
    print("[INFO] Folder /opt/app_data already exists")
else:
    print("[INFO] Folder not found. Creating...")
    stdin, stdout, stderr = ssh.exec_command('sudo mkdir -p /opt/app_data')
    stdout.channel.recv_exit_status()
    print("[SUCCESS] Folder created successfully")

# Set permissions
print("\n[3] Setting 644 permissions...")
stdin, stdout, stderr = ssh.exec_command('sudo chmod 644 /opt/app_data')
stdout.channel.recv_exit_status()
print("[SUCCESS] Permissions set")

# Check and start httpd service
print("\n[4] Checking httpd service...")
stdin, stdout, stderr = ssh.exec_command('systemctl is-active httpd')
status = stdout.read().decode('utf-8').strip()

if status == 'active':
    print("[INFO] httpd service is already running")
else:
    print("[INFO] Starting httpd service...")
    ssh.exec_command('sudo systemctl start httpd')
    ssh.exec_command('sudo systemctl enable httpd')
    print("[SUCCESS] httpd service started successfully")

print("\n" + "="*50)
print("DEV DEPLOYMENT COMPLETED!")
print("="*50)

ssh.close()
