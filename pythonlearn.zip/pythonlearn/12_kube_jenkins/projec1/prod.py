import paramiko
import sys

if len(sys.argv) < 2:
    print("Usage: python3 prod.py <ip_address>")
    sys.exit(1)

target_ip = sys.argv[1]

print("="*50)
print("PROD ENVIRONMENT DEPLOYMENT")
print(f"Target IP: {target_ip}")
print("="*50)

# Connect to target server
print(f"\nConnecting to {target_ip}...")
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(target_ip, username='jenkinsadm', look_for_keys=True, allow_agent=True)
print("Connected successfully!")

# Check and install Java
print("\n[1] Checking Java...")
stdin, stdout, stderr = ssh.exec_command('which java')
exit_code = stdout.channel.recv_exit_status()

if exit_code == 0:
    print("[INFO] Java is already installed")
else:
    print("[INFO] Java not found. Installing...")
    stdin, stdout, stderr = ssh.exec_command('sudo yum install -y java-1.8.0-openjdk')
    stdout.channel.recv_exit_status()
    print("[SUCCESS] Java installed successfully")

# Verify Java
print("\n[2] Verifying Java installation...")
stdin, stdout, stderr = ssh.exec_command('java -version')
output = stderr.read().decode('utf-8')
print(output)
print("[SUCCESS] Java verified")

print("\n" + "="*50)
print("PROD DEPLOYMENT COMPLETED!")
print("="*50)

ssh.close()
