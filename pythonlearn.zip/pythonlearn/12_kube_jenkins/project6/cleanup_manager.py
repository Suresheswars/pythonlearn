#!/usr/bin/env python3
from kubernetes import client, config
from datetime import datetime, timedelta

print("="*60)
print("KUBERNETES CLEANUP MANAGER")
print(f"Run Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("="*60)

# Load kubeconfig
try:
    config.load_incluster_config()  # For running inside cluster
except:
    config.load_kube_config()  # For local testing

v1 = client.CoreV1Api()
apps_v1 = client.AppsV1Api()
metrics_api = client.CustomObjectsApi()

namespace = "devproject"

# Task 1: Scale down deployments if replicas > 5
print("\n[1] Checking Deployments with replicas > 5:")
print(f"Namespace: {namespace}")
try:
    deployments = apps_v1.list_namespaced_deployment(namespace)
    scaled_count = 0
    
    for deployment in deployments.items:
        deployment_name = deployment.metadata.name
        current_replicas = deployment.spec.replicas
        
        if current_replicas > 5:
            print(f"  Deployment: {deployment_name}")
            print(f"    Current Replicas: {current_replicas}")
            print(f"    [ACTION] Scaling down to 4 replicas...")
            
            # Scale down to 4
            deployment.spec.replicas = 4
            apps_v1.patch_namespaced_deployment(
                name=deployment_name,
                namespace=namespace,
                body=deployment
            )
            print(f"    [SUCCESS] Scaled down to 4 replicas")
            print()
            scaled_count += 1
    
    if scaled_count == 0:
        print("  No deployments with > 5 replicas found")
    else:
        print(f"Total deployments scaled down: {scaled_count}")
except Exception as e:
    print(f"  Error checking deployments: {str(e)}")

# Task 2: Scale down underutilized deployments
print("\n" + "="*60)
print("[2] Checking Underutilized Deployments:")
print(f"Namespace: {namespace}")
try:
    deployments = apps_v1.list_namespaced_deployment(namespace)
    
    # Try to get pod metrics
    try:
        pod_metrics = metrics_api.list_namespaced_custom_object(
            group="metrics.k8s.io",
            version="v1beta1",
            namespace=namespace,
            plural="pods"
        )
        
        metrics_dict = {}
        for item in pod_metrics.get('items', []):
            pod_name = item['metadata']['name']
            metrics_dict[pod_name] = item
    except:
        print("  [WARNING] Metrics server not available. Skipping underutilization check.")
        metrics_dict = {}
    
    if metrics_dict:
        scaled_down_count = 0
        
        for deployment in deployments.items:
            deployment_name = deployment.metadata.name
            current_replicas = deployment.spec.replicas
            
            # Skip if already at minimum
            if current_replicas <= 2:
                continue
            
            # Get pods for this deployment
            # Get the deployment's selector labels
            deployment_obj = apps_v1.read_namespaced_deployment(deployment_name, namespace)
            selector_labels = deployment_obj.spec.selector.match_labels
            
            # Build label selector string
            label_selector = ','.join([f"{k}={v}" for k, v in selector_labels.items() if k != 'pod-template-hash'])
            
            pods = v1.list_namespaced_pod(
                namespace,
                label_selector=label_selector
            )
            
            if not pods.items:
                continue
            
            # Calculate average utilization across all pods
            total_utilization = 0
            pod_count = 0
            
            for pod in pods.items:
                if pod.status.phase != 'Running':
                    continue
                
                pod_name = pod.metadata.name
                
                if not pod.spec.containers:
                    continue
                
                container = pod.spec.containers[0]
                
                if not (container.resources and container.resources.requests):
                    continue
                
                cpu_request = container.resources.requests.get('cpu', 'Not set')
                memory_request = container.resources.requests.get('memory', 'Not set')
                
                if cpu_request == 'Not set' or memory_request == 'Not set':
                    continue
                
                if pod_name in metrics_dict:
                    containers_metrics = metrics_dict[pod_name].get('containers', [])
                    
                    for cont_metric in containers_metrics:
                        if cont_metric['name'] == container.name:
                            cpu_usage = cont_metric['usage'].get('cpu', '0')
                            memory_usage = cont_metric['usage'].get('memory', '0')
                            
                            try:
                                # Convert CPU
                                cpu_usage_val = int(cpu_usage.replace('n', '')) / 1000000 if 'n' in cpu_usage else int(cpu_usage.replace('m', ''))
                                cpu_request_val = int(cpu_request.replace('m', ''))
                                cpu_percent = (cpu_usage_val / cpu_request_val) * 100 if cpu_request_val > 0 else 0
                                
                                # Convert Memory
                                memory_usage_val = int(memory_usage.replace('Ki', ''))
                                memory_request_val = int(memory_request.replace('Mi', '')) * 1024
                                memory_percent = (memory_usage_val / memory_request_val) * 100 if memory_request_val > 0 else 0
                                
                                # Average utilization for this pod
                                pod_utilization = (cpu_percent + memory_percent) / 2
                                total_utilization += pod_utilization
                                pod_count += 1
                            except:
                                pass
            
            if pod_count > 0:
                avg_deployment_utilization = total_utilization / pod_count
                
                print(f"  Deployment: {deployment_name}")
                print(f"    Replicas: {current_replicas}")
                print(f"    Average Utilization: {avg_deployment_utilization:.1f}%")
                
                # Scale down if underutilized
                if avg_deployment_utilization < 20:
                    new_replicas = max(2, current_replicas - 1)
                    print(f"    [ACTION] Scaling down from {current_replicas} to {new_replicas} replicas...")
                    
                    deployment.spec.replicas = new_replicas
                    apps_v1.patch_namespaced_deployment(
                        name=deployment_name,
                        namespace=namespace,
                        body=deployment
                    )
                    print(f"    [SUCCESS] Scaled down to {new_replicas} replicas")
                    scaled_down_count += 1
                else:
                    print(f"    [OK] Adequately utilized")
                print()
        
        if scaled_down_count == 0:
            print("  No underutilized deployments to scale down")
        else:
            print(f"Total underutilized deployments scaled down: {scaled_down_count}")
    else:
        print("  Skipping underutilization check (no metrics available)")
except Exception as e:
    print(f"  Error checking underutilization: {str(e)}")

print("\n" + "="*60)
print("CLEANUP COMPLETE!")
print("="*60)
