mapping = {'name': 'santhosh', 'age': 35, 'city': 'chennai' }
print(mapping)
print(mapping['name'])
print(mapping['age'])
print(mapping['city'])

