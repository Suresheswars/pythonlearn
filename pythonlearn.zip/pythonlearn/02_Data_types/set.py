
#set
test = {1, 2, 3, 4, 4, 5}
print(test)

test = {1, 2, 3, 4, 4, 5}
test.add(6)
print(test)

#Frozen set
# test = frozenset({1, 2, 3, 4, 4, 5})
# test.add(6)
# print(test)

# my_list = [1,2,3,4,5]
# my_list.insert(3, 7)
# print(my_list)