a = 10
b = None

print(b)