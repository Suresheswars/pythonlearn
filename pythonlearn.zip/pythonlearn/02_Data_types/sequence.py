
# a = "raj"
# b = 'kumar'
#
# c = "This is hemanth's car"
#
# d = ''' This is hemanth
# I play cricket
# I like movies
# I am star in my office'''
#
# print(a)
# print(b)
# print(c)
# print(d)

#reverse a string

# s = "hello_world"
# reverse = s[::-1]
# print(reverse)
#
# #another method
# sa = "ashok"
# rev_new = "".join(reversed(sa))
# print(rev_new)

#list and tuples

# a = [ 1, 2, 3, 'test']
# print(a[3])

#tuples
# a =  1, 2, 3, 'test'
#
# print(a)

#range

numbers = list(range(5))

print(numbers)

numbers2= list(range(1, 10, 2))

print(numbers2)

#reverse

numbers3 = list(range(10, 0, -1))

print(numbers3)

