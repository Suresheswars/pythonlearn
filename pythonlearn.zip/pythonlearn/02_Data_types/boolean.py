
is_morning = True
is_evening = False

if is_morning:
    print("Go to work")
else:
    print("Go back to home")