import subprocess
import os
import re
import requests
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from fastapi import FastAPI, Request
import uvicorn
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent
from langchain_core.tools import tool
import config

os.environ["OPENAI_API_KEY"] = config.OPENAI_API_KEY

app = FastAPI()

class MetricsHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/metrics':
            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            try:
                self.wfile.write(self.get_metrics().encode())
            except BrokenPipeError:
                pass
        else:
            self.send_response(404)
            self.end_headers()
    
    def log_message(self, *args):
        pass
    
    def get_metrics(self):
        result = subprocess.getoutput('docker stats --no-stream --format "{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}"')
        lines = ["# HELP container_cpu_percent CPU", "# TYPE container_cpu_percent gauge",
                 "# HELP httpd_service_up Service status", "# TYPE httpd_service_up gauge"]
        for row in result.strip().split('\n'):
            if '|' in row:
                parts = row.split('|')
                if len(parts) >= 2:
                    name, cpu = parts[0].strip(), parts[1].strip().replace('%', '')
                    try:
                        lines.append(f'container_cpu_percent{{name="{name}"}} {float(cpu)}')
                    except:
                        pass
        httpd_check = subprocess.getoutput('docker exec httpd-server ps aux')
        httpd_up = 1 if any('httpd' in l and 'defunct' not in l and 'Ss' in l for l in httpd_check.split('\n')) else 0
        lines.append(f'httpd_service_up {httpd_up}')
        return '\n'.join(lines) + '\n'

def start_exporter():
    HTTPServer(('0.0.0.0', 9200), MetricsHandler).serve_forever()

def fetch_confluence_runbooks():
    url = f"{config.CONFLUENCE_URL}/rest/api/content/{config.CONFLUENCE_PARENT_PAGE_ID}/child/page?expand=body.storage"
    try:
        response = requests.get(url, auth=(config.CONFLUENCE_USER, config.CONFLUENCE_TOKEN))
        if response.status_code == 200:
            return [{'title': p['title'], 'content': re.sub('<[^<]+?>', '', p['body']['storage']['value']).strip()}
                    for p in response.json().get('results', [])]
    except:
        pass
    return []

def normalize(text: str) -> str:
    return re.sub(r'[^a-z0-9]', '', text.lower())

@tool
def search_runbook(keyword: str) -> str:
    """Search Confluence runbooks by keyword."""
    runbooks = fetch_confluence_runbooks()
    print(f"[SEARCH] {keyword}")
    keyword_normalized = normalize(keyword)
    for rb in runbooks:
        title_normalized = normalize(rb['title'])
        if keyword_normalized in title_normalized or title_normalized in keyword_normalized or keyword.lower() in rb['content'].lower():
            print(f"[FOUND] {rb['title']}")
            return f"RUNBOOK: {rb['title']}\n\n{rb['content']}"
    print(f"[NOT FOUND] {keyword}")
    return f"NO RUNBOOK FOUND for '{keyword}'."

@tool
def execute_command(command: str) -> str:
    """Execute a shell command from the runbook."""
    print(f"[EXECUTE] {command}")
    result = subprocess.getoutput(command)
    print(f"[RESULT] {result}")
    return f"Executed: {command}\nResult: {result}"

SYSTEM_PROMPT = """You are a DevOps remediation agent that follows Confluence runbooks EXACTLY.

STRICT RULES:
1. Search the runbook FIRST using search_runbook tool
2. If NO RUNBOOK found -> respond "No runbook found."
3. If RUNBOOK found -> look for lines starting with "Command:" 
4. Extract the EXACT command string after "Command:" and execute it using execute_command tool
5. NEVER generate your own commands. NEVER use systemctl, service, or /etc/init.d
6. ONLY execute commands that appear after "Command:" in the runbook text
7. Copy the command EXACTLY as written, do not modify it"""

def create_ai_agent():
    llm = ChatOpenAI(model=config.DEFAULT_MODEL_OPENAI, temperature=0)
    return create_agent(model=llm, tools=[search_runbook, execute_command], system_prompt=SYSTEM_PROMPT)

AGENT = create_ai_agent()

def process_alert(alert: dict) -> str:
    alert_name = alert.get('labels', {}).get('alertname', 'Unknown')
    container = alert.get('labels', {}).get('container', '')
    description = alert.get('annotations', {}).get('description', '')
    print(f"\n[ALERT] {alert_name} | {container}")
    prompt = f"Alert: {alert_name}\nContainer: {container}\nDescription: {description}\n\nSearch runbook and follow remediation steps."
    result = AGENT.invoke({"messages": [{"role": "user", "content": prompt}]})
    response = result['messages'][-1].content
    print(f"[DONE] {response[:100]}...")
    return response

@app.post("/webhook")
async def webhook(request: Request):
    data = await request.json()
    responses = []
    for alert in data.get('alerts', []):
        if alert.get('status') == 'firing':
            responses.append({"alert": alert.get('labels', {}).get('alertname'), "response": process_alert(alert)})
    return {"status": "processed", "responses": responses}

@app.get("/test")
async def test(type: str = "httpd"):
    if type == "httpd":
        alert = {"labels": {"alertname": "HTTPDServiceDown", "container": "httpd-server"}, "annotations": {"description": "HTTPD service is down"}}
    else:
        alert = {"labels": {"alertname": "HighCPU", "container": "webserver"}, "annotations": {"description": "CPU usage is high"}}
    return {"response": process_alert(alert)}

@app.get("/health")
async def health():
    return {"status": "healthy"}

if __name__ == "__main__":
    threading.Thread(target=start_exporter, daemon=True).start()
    subprocess.getoutput('docker exec httpd-server httpd -k start')
    print("Agent Started")
    uvicorn.run(app, host="0.0.0.0", port=5000, log_level="error")
