OPENAI_API_KEY = "sk-proj-Ua6VPyxhpgWhlW5WOjwbl0KIBu5T3BlbkFJhAe33BF0uVF4cOCks2hLFNP1o5GDQpJDwO5ewrP4rOE_qGG9-5lPDi-dxZsP_zKeUa53GfHXQA"
DEFAULT_MODEL_OPENAI = "gpt-4o-mini"

# Confluence Configuration
CONFLUENCE_URL = "https://wetechi.atlassian.net/wiki"
CONFLUENCE_USER = "management@wetechzone.com"
CONFLUENCE_TOKEN = "ATATT3xFYJ-zfxLIuw3uWBsJLtcEzYZKuuBXD5a3Q-Sp2qpm5Jes_izERzFWdBTAoW4g6769RhM0eOj7noQE6FepX39y8Pp1H7681oSe0QQ=6813B229"

# Parent Page ID - All runbooks are child pages under this
CONFLUENCE_PARENT_PAGE_ID = "44681"
