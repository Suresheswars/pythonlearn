
from http.server import HTTPServer, BaseHTTPRequestHandler
import subprocess
import re

PORT = 9200

class MetricsHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/metrics':
            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            self.wfile.write(self.get_metrics().encode())
        else:
            self.send_response(404)
            self.end_headers()
    
    def log_message(self, *args):
        pass
    
    def get_metrics(self):
        result = subprocess.getoutput(
            'docker stats --no-stream --format "{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}"'
        )
        lines = [
            "# HELP container_cpu_percent CPU percentage",
            "# TYPE container_cpu_percent gauge",
            "# HELP container_memory_bytes Memory bytes",
            "# TYPE container_memory_bytes gauge",
            "# HELP httpd_service_up Apache httpd service status (1=up, 0=down)",
            "# TYPE httpd_service_up gauge"
        ]
        
        for row in result.strip().split('\n'):
            if '|' not in row:
                continue
            parts = row.split('|')
            if len(parts) < 3:
                continue
            name = parts[0].strip()
            cpu = parts[1].strip().replace('%', '')
            mem = parts[2].strip().split('/')[0].strip()
            try:
                lines.append(f'container_cpu_percent{{name="{name}"}} {float(cpu)}')
                lines.append(f'container_memory_bytes{{name="{name}"}} {self.parse_mem(mem)}')
            except:
                pass
        
        # Check httpd service status
        httpd_up = self.check_httpd()
        lines.append(f'httpd_service_up {httpd_up}')
        
        return '\n'.join(lines) + '\n'
    
    def check_httpd(self):
        """Check if httpd is running (not zombie)."""
        result = subprocess.getoutput('docker exec httpd-server ps aux')
        for line in result.split('\n'):
            if 'httpd' in line and 'defunct' not in line and 'grep' not in line:
                # Check if it's a real running process (has Ss or Sl status)
                if ' Ss ' in line or ' Sl ' in line or ' S ' in line:
                    return 1
        return 0
    
    def parse_mem(self, s):
        m = re.match(r'([\d.]+)\s*(\w+)', s)
        if not m:
            return 0
        val, unit = float(m.group(1)), m.group(2).lower()
        return int(val * {'b': 1, 'kib': 1024, 'mib': 1024**2, 'gib': 1024**3}.get(unit, 1))

if __name__ == "__main__":
    print(f"Exporter: http://localhost:{PORT}/metrics")
    try:
        HTTPServer(('0.0.0.0', PORT), MetricsHandler).serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
