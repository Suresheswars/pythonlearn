import subprocess
import time
import os
from langchain_openai import ChatOpenAI
from langchain.agents import create_agent
from langchain_core.tools import tool
from config import OPENAI_API_KEY, DEFAULT_MODEL_OPENAI

os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

CHECK_INTERVAL = 5
CPU_THRESHOLD = 50


@tool
def get_container_stats(container: str) -> str:
    """Get CPU and Memory stats of a Docker container."""
    stats = subprocess.getoutput(
        f'docker stats {container} --no-stream --format "CPU: {{{{.CPUPerc}}}} | Memory: {{{{.MemUsage}}}}"'
    )
    status = subprocess.getoutput(
        f'docker inspect {container} --format "{{{{.State.Status}}}}"'
    )
    return f"Container: {container}\n{stats}\nStatus: {status}"


@tool
def restart_container(container: str) -> str:
    """Restart a Docker container to fix high CPU issues."""
    subprocess.getoutput(f"docker restart {container}")
    status = subprocess.getoutput(
        f'docker inspect {container} --format "{{{{.State.Status}}}}"'
    )
    return f"Container {container} restarted. Current status: {status}"


@tool
def check_httpd_service() -> str:
    """Check if Apache httpd service is running inside httpd-server container."""
    result = subprocess.getoutput('docker exec httpd-server pgrep -x httpd')
    if result.strip():
        return "Apache httpd service is RUNNING (PID: " + result.strip().split()[0] + ")"
    else:
        return "Apache httpd service is STOPPED"


@tool
def start_httpd_service() -> str:
    """Start Apache httpd service inside httpd-server container."""
    subprocess.getoutput('docker exec httpd-server httpd -k start')
    time.sleep(1)
    result = subprocess.getoutput('docker exec httpd-server pgrep -x httpd')
    if result.strip():
        return "Apache httpd service STARTED successfully"
    else:
        return "Failed to start Apache httpd service"

def create_agent_once():
    """Create agent once and reuse."""
    llm = ChatOpenAI(model=DEFAULT_MODEL_OPENAI)
    return create_agent(
        model=llm,
        tools=[get_container_stats, restart_container, check_httpd_service, start_httpd_service],
        system_prompt=f"""You are a DevOps auto-remediation agent.

Available tools:
- get_container_stats: Get CPU/Memory stats of a container
- restart_container: Restart a container (for high CPU)
- check_httpd_service: Check if Apache httpd service is running
- start_httpd_service: Start Apache httpd service

Rules:
1. If httpd service is STOPPED -> use start_httpd_service
2. If CPU > {CPU_THRESHOLD}% -> use restart_container
3. If everything is normal -> report no action needed
4. Always report what you found and did"""
    )


def get_container_cpu(container):
    """Get container CPU percentage."""
    cpu_str = subprocess.getoutput(
        f'docker stats {container} --no-stream --format "{{{{.CPUPerc}}}}"'
    ).strip().replace('%', '')
    try:
        return float(cpu_str)
    except:
        return 0.0


def is_httpd_service_running():
    """Check if httpd service is running (exclude zombie processes)."""
    result = subprocess.getoutput('docker exec httpd-server ps aux')
    # Look for httpd process that's not defunct/zombie
    for line in result.split('\n'):
        if 'httpd' in line and 'defunct' not in line and 'grep' not in line and 'Ss' in line:
            return True
    return False


def main():
    print("\nLangChain Auto-Remediation Agent")
    print("=" * 50)
    print("Monitoring:")
    print("  - webserver (nginx) - CPU")
    print("  - httpd-server (Apache service)")
    print(f"CPU Threshold: {CPU_THRESHOLD}%")
    print(f"Interval: {CHECK_INTERVAL}s")
    print("Press Ctrl+C to stop")
    print("=" * 50)
    
    agent = create_agent_once()
    
    while True:
        try:
            timestamp = time.strftime('%H:%M:%S')
            print(f"\n[{timestamp}] Checking...")
            
            # Check webserver CPU
            webserver_cpu = get_container_cpu("webserver")
            if webserver_cpu > CPU_THRESHOLD:
                print(f"  webserver: CPU {webserver_cpu}% HIGH - Running agent...")
                result = agent.invoke({
                    "messages": [{"role": "user", "content": f"HighCPU on webserver. CPU is {webserver_cpu}%. Fix it."}]
                })
                print(f"  Agent: {result['messages'][-1].content}")
            else:
                print(f"  webserver: OK (CPU: {webserver_cpu}%)")
            
            # Check httpd service
            if not is_httpd_service_running():
                print(f"  httpd-server: Apache service STOPPED - Running agent...")
                result = agent.invoke({
                    "messages": [{"role": "user", "content": "Apache httpd service is stopped. Start it."}]
                })
                print(f"  Agent: {result['messages'][-1].content}")
            else:
                httpd_cpu = get_container_cpu("httpd-server")
                if httpd_cpu > CPU_THRESHOLD:
                    print(f"  httpd-server: CPU {httpd_cpu}% HIGH - Running agent...")
                    result = agent.invoke({
                        "messages": [{"role": "user", "content": f"HighCPU on httpd-server. CPU is {httpd_cpu}%. Fix it."}]
                    })
                    print(f"  Agent: {result['messages'][-1].content}")
                else:
                    print(f"  httpd-server: Apache RUNNING (CPU: {httpd_cpu}%)")
            
            time.sleep(CHECK_INTERVAL)
            
        except KeyboardInterrupt:
            print("\n\nStopped.")
            break


if __name__ == "__main__":
    main()
