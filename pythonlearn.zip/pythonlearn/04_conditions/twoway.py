num = eval(input("Enter the number: "))

if num == 1:
    print("valid")
else:
    print("not valid")
####

str = input("Enter the string: ")
if str == "raj":
    print("String is valid")
else:
    print("String is not valid")