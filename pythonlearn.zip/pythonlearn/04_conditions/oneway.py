
num = eval(input("Enter the number: "))

if num == 1:
    print("valid")
###
str = "kumar"

if str == "kumar":
    print("Sring is valid")
###
str = input("Enter the string: ")

if str == "kumar":
    print("Sring is valid")
