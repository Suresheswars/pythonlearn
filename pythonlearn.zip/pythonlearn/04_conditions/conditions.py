
country = ['india', 'japan', 'uk']

if 'india' or 'tokyo' in country:
    print("The country is available")
else:
    print("Not available")