name = 'python'
if 'p' in name:
    if 'a' in name:
        print("Available")
    else:
        print("a is not available")
else:
    print("Not available")