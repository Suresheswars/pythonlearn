# disk_space = eval(input("Enter the number: "))
#
#
# if disk_space > 90:
#     print(f" Entered {disk_space} is critical , send notification")
# elif disk_space >= 80:
#     print(f" Entered {disk_space} is greate so give warning")
# elif disk_space < 30:
#     print(f" Entered {disk_space} is below 30, so we are safe")
# else:
#     print("Enter a valid number")

# disk_space = eval(input("Enter the number: "))
#
# if disk_space > 90:
#     print(f" Entered {disk_space} is critical , send notification")
# elif disk_space >= 80:
#     print(f" Entered {disk_space} is greate so give warning")
# elif disk_space < 30:
#     print(f" Entered {disk_space} is below 30, so we are safe")
# else:
#     pass


num = input("Enter the number: ")

try:

    if num > 0:
        print(f" Entered {num} is greater than 0")
    elif num < 0:
        print(f" Entered {num} is less than 0")
    elif num == 0:
        print(f" Entered {num} is zero")
    else:
        pass
except Exception as err:
    print(f"The enterered {num} is not a valid number")
    print(err)