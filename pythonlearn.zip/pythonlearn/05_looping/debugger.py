num_list = [10, 20, 30, 40]

total = 0

for num in num_list:
    import pdb;
    pdb.set_trace()
    total = total + num

print(total)