
name = 'python'

for i in name:
    print(i)
#################

fruits_list = ['apple', 'orange', 'grapes', 'kiwi']

for fruits in fruits_list:
    if fruits == 'apple':
        print(f"{fruits} is my favorite fruit")
    elif fruits == ('grapes'):
        print(f"{fruits} is also good, but not my favorite fruit")
    else:
        print(f"{fruits} is not my favorite fruit")

#################


for i in range(2, 6):
    print(i)

guess_number= int(input("Enter the number I will guess your number "))
secret_number = 7
max_attempts = 5
attempts = 0

while attempts < max_attempts:
    if guess_number <= secret_number:
        print(" Your number is less than secret number")
    elif guess_number >= secret_number:
        print(" Your number is greater than secret number")
    elif guess_number == secret_number:
        print(" Your number is crt secret number")


