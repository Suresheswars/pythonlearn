
i = 0

while i < 10:
    print(i)
    i = i + 1

j = int(input("How many times: "))
i = 0
while i < j:
    num = int(input("Enter the number: "))

    if num == 0:
        print("Number is zero")
    elif num > 0:
        print("positive")
    else:
        print("Negative")
    i += 1

i = 100

while i >= 100 and i <=200:
    print(i)
    i = i + 2

i = 100

while i >= 100 and i <=200:
    print(i, end=' ')
    i = i + 2