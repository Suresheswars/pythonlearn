
list1 = [10, 20, 30]
list2 = [1, 2, 3]

for i in list1:
    for j in list2:
        print(i+j, end=' ')

colour = ["Red", "Blue"]

clothes = ["Shirts", "Pants"]

for i in colour:
    for j in clothes:
        print(i, j)


fruits_list = ['apple', 'banana', 'grapes']
for fruits in fruits_list:
    print(fruits)
    if fruits == 'banana':
        for f in fruits:
            print(f, end=' ')
            print()

while

employee = 1

while employee <= 2:  #outer loop
    task = 1
    while task <= 3:   # inner loop
        print(f"Employee {employee} picks the Task {task} ")
        task += 1
    employee += 1