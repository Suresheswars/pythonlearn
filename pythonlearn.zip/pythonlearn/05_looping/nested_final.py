
employees = ["Alice", "Bob"]
for employee in employees:
    print(f"{employee} starts working on tasks:")


    task = 1
    while task <= 3:              
        print(f"  Task {task} completed by {employee}")
        task += 1


    print(f"{employee} finished all tasks!\n")