
import moduledemo

a = moduledemo.add(12, 6)
print(a)

b = moduledemo.sub(12, 6)
print(b)


#print(funcnam.upper("hello"))