
users = ["hemanth", "vishnu", "Sasi", "raja", "kumar"]
inactive_users = ["vishnu"]  # to handle later
on_leave = ["Sasi"]            # skip for now
banned_users = ["raja"]      # stop all emails


for user in users:
    if user in inactive_users:
        pass  # we will handle inactive users later
    elif user in on_leave:
        continue  # skip this user, continue with next
    elif user in banned_users:
        print(f"{user} is banned! Stopping all emails.")
        break   # stop the loop completely
    print(f"Email sent to {user}")