
s = 'testing'

for letter in s:
    if letter == 's':
        break
    print(letter)

#####
users = ["hemanth", "hepzi", "kabilan", "karthik"]

inactive_users = ["kabilan"]

for user in users:
    if user in inactive_users:
        print(f"{user} is inactive!")
        break
    print(f"Email sent to {user}")