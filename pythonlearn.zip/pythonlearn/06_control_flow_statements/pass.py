s = 'testing'

for letter in s:
    if letter == 's':
        pass
    print(letter)

#####
users = ["hemanth", "hepzi", "kabilan", "karthik"]

inactive_users = ["kabilan"]

for user in users:
    if user in inactive_users:
        pass
    print(f"Email sent to {user}")