import subprocess, time, threading, requests, asyncio, queue
from datetime import datetime
from typing import TypedDict, Literal
from collections import defaultdict
from http.server import HTTPServer, BaseHTTPRequestHandler
from fastapi import FastAPI, Request
import uvicorn
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from mcp import ClientSession
from mcp.client.sse import sse_client
import config

app = FastAPI()
audit_logs, pending_approvals = [], {}
rate_limit_tracker = defaultdict(list)

mcp_queue = queue.Queue()
mcp_results = {}
mcp_connected = False

ALERT_TO_TOOL = {
    "HTTPDServiceDown": {"action": "start_httpd", "rollback": "stop_httpd", "container": "httpd-server", "severity": "critical"},
    "HighCPU": {"action": "kill_high_cpu", "rollback": "restart_container", "container": "webserver", "severity": "warning"},
}


async def mcp_worker():
    global mcp_connected
    async with sse_client(config.MCP_SERVER_URL) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = await session.list_tools()
            print(f"MCP Tools: {[t.name for t in tools.tools]}")
            mcp_connected = True
            while True:
                try:
                    req_id, tool, args = mcp_queue.get_nowait()
                    result = await session.call_tool(tool, args)
                    text = result.content[0].text if result.content else "OK"
                    mcp_results[req_id] = text
                except queue.Empty:
                    await asyncio.sleep(0.1)
                except Exception as e:
                    if 'req_id' in dir():
                        mcp_results[req_id] = f"Error: {e}"


def mcp_call(tool: str, container: str) -> str:
    req_id = f"{tool}_{time.time()}"
    mcp_queue.put((req_id, tool, {"container": container}))
    for _ in range(100):
        if req_id in mcp_results:
            result = mcp_results.pop(req_id)
            return result
        time.sleep(0.1)
    return "Timeout"


class State(TypedDict):
    alert_id: str
    alert_name: str
    container: str
    severity: str
    action: str
    rollback: str
    dry_run: bool
    approvals_needed: int
    approved: bool
    verified: bool
    retries: int
    status: str
    ticket: str


def log(id, action, msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {action}: {msg[:80]}")
    audit_logs.append({"ts": datetime.now().isoformat(), "id": id, "action": action, "msg": msg})


def rate_ok(name):
    now = time.time()
    rate_limit_tracker[name] = [t for t in rate_limit_tracker[name] if t > now - config.RATE_LIMIT_WINDOW_SECONDS]
    if len(rate_limit_tracker[name]) >= config.RATE_LIMIT_MAX:
        return False
    rate_limit_tracker[name].append(now)
    return True


def jira_create(alert, container):
    try:
        r = requests.post(f"{config.JIRA_URL}/rest/api/3/issue", auth=(config.JIRA_EMAIL, config.JIRA_TOKEN), 
            headers={"Content-Type": "application/json"},
            json={"fields": {"project": {"key": config.JIRA_PROJECT_KEY}, "summary": f"{alert} on {container}",
                "description": {"type": "doc", "version": 1, "content": [{"type": "paragraph", "content": [{"type": "text", "text": f"Alert received for {container}"}]}]},
                "issuetype": {"name": "Task"}}})
        if r.status_code in [200, 201]:
            return r.json().get("key")
    except: pass
    return f"LOCAL-{int(time.time())}"


def jira_close(ticket, msg):
    if ticket.startswith("LOCAL"): return
    try:
        requests.post(f"{config.JIRA_URL}/rest/api/3/issue/{ticket}/comment", auth=(config.JIRA_EMAIL, config.JIRA_TOKEN),
            headers={"Content-Type": "application/json"},
            json={"body": {"type": "doc", "version": 1, "content": [{"type": "paragraph", "content": [{"type": "text", "text": msg}]}]}})
        r = requests.get(f"{config.JIRA_URL}/rest/api/3/issue/{ticket}/transitions", auth=(config.JIRA_EMAIL, config.JIRA_TOKEN))
        transitions = r.json().get("transitions", [])
        done = next((t for t in transitions if t["name"].lower() in ["done", "closed", "complete", "resolved", "finish"]), None)
        if done:
            requests.post(f"{config.JIRA_URL}/rest/api/3/issue/{ticket}/transitions", auth=(config.JIRA_EMAIL, config.JIRA_TOKEN),
                headers={"Content-Type": "application/json"}, json={"transition": {"id": done["id"]}})
            print(f"[JIRA] {ticket} → {done['name']}")
        else:
            print(f"[JIRA] {ticket} transitions: {[t['name'] for t in transitions]}")
    except Exception as e:
        print(f"[JIRA] Error: {e}")


def slack_send(id, name, container, action, dry_run):
    if not config.SLACK_WEBHOOK_URL: return
    requests.post(config.SLACK_WEBHOOK_URL, json={"blocks": [
        {"type": "header", "text": {"type": "plain_text", "text": f"{name}{' [DRY-RUN]' if dry_run else ''}"}},
        {"type": "section", "text": {"type": "mrkdwn", "text": f"*Container:* {container}\n*Action:* `{action}`"}},
        {"type": "actions", "elements": [
            {"type": "button", "text": {"type": "plain_text", "text": "APPROVE"}, "style": "primary", "url": f"{config.AGENT_PUBLIC_URL}/approve/{id}"},
            {"type": "button", "text": {"type": "plain_text", "text": "REJECT"}, "style": "danger", "url": f"{config.AGENT_PUBLIC_URL}/reject/{id}"}
        ]}
    ]})


def slack_result(name, status, ticket):
    if not config.SLACK_WEBHOOK_URL: return
    link = f" | <{config.JIRA_URL}/browse/{ticket}|{ticket}>" if not ticket.startswith("LOCAL") else ""
    requests.post(config.SLACK_WEBHOOK_URL, json={"attachments": [{"color": "#36a64f" if status == "success" else "#ff0000", "text": f"*{name}* - {status.upper()}{link}"}]})


class MetricsHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/metrics':
            try:
                self.send_response(200)
                self.send_header('Content-type', 'text/plain')
                self.end_headers()
                stats = subprocess.getoutput('docker stats --no-stream --format "{{.Name}}|{{.CPUPerc}}"')
                lines = ["# TYPE container_cpu_percent gauge", "# TYPE httpd_service_up gauge"]
                for row in stats.strip().split('\n'):
                    if '|' in row:
                        n, c = row.split('|')[0].strip(), row.split('|')[1].strip().replace('%', '')
                        try: lines.append(f'container_cpu_percent{{name="{n}"}} {float(c)}')
                        except: pass
                ps = subprocess.getoutput('docker exec httpd-server ps aux')
                lines.append(f'httpd_service_up {1 if any("httpd" in l and "defunct" not in l and "Ss" in l for l in ps.split(chr(10))) else 0}')
                self.wfile.write('\n'.join(lines).encode())
            except: pass
    def log_message(self, *a): pass


def node_ticket(s: State) -> State:
    ticket = jira_create(s['alert_name'], s['container'])
    log(s['alert_id'], "JIRA", f"Created {ticket}")
    return {**s, "ticket": ticket, "status": "ticket_created"}

def node_rate(s: State) -> State:
    if not rate_ok(s['alert_name']):
        log(s['alert_id'], "RATE", "Blocked")
        return {**s, "status": "rate_limited"}
    return {**s, "status": "rate_ok"}

def node_map(s: State) -> State:
    m = ALERT_TO_TOOL.get(s['alert_name'])
    if not m:
        log(s['alert_id'], "MAP", "No mapping")
        return {**s, "status": "no_mapping"}
    approvals = config.APPROVALS_REQUIRED_CRITICAL if m["severity"] == "critical" else config.APPROVALS_REQUIRED_NORMAL
    log(s['alert_id'], "MAP", m["action"])
    return {**s, "action": m["action"], "rollback": m.get("rollback") or "", "severity": m["severity"], "approvals_needed": approvals, "status": "mapped"}

def node_approval(s: State) -> State:
    id = s['alert_id']
    pending_approvals[id] = {"count": 0, "done": None, "need": s['approvals_needed']}
    log(id, "WAIT", f"Need {s['approvals_needed']} approval")
    slack_send(id, s['alert_name'], s['container'], s['action'], s['dry_run'])
    while pending_approvals[id]["done"] is None:
        if pending_approvals[id]["count"] >= s['approvals_needed']:
            pending_approvals[id]["done"] = True
        time.sleep(1)
    ok = pending_approvals[id]["done"]
    del pending_approvals[id]
    log(id, "APPROVAL", "Approved" if ok else "Rejected")
    return {**s, "approved": ok, "status": "approved" if ok else "rejected"}

def node_dry(s: State) -> State:
    if s['dry_run']:
        log(s['alert_id'], "DRY", s['action'])
        return {**s, "status": "dry_done"}
    return {**s, "status": "ready"}

def node_exec(s: State) -> State:
    log(s['alert_id'], "EXEC", s['action'])
    mcp_call(s['action'], s['container'])
    time.sleep(1)
    return {**s, "status": "executed"}

def node_verify(s: State) -> State:
    try:
        ok = False
        if "httpd" in s['alert_name'].lower():
            result = mcp_call("check_httpd", s['container'])
            ok = "RUNNING" in result
        else:
            ok = True
        log(s['alert_id'], "VERIFY", "OK" if ok else "Failed")
        if ok:
            return {**s, "verified": True, "status": "success"}
        return {**s, "verified": False, "retries": s['retries'] + 1, "status": "failed"}
    except Exception as e:
        print(f"[ERROR] verify: {e}")
        return {**s, "verified": True, "status": "success"}

def node_rollback(s: State) -> State:
    if s['retries'] >= 3 and s['rollback']:
        log(s['alert_id'], "ROLLBACK", s['rollback'])
        mcp_call(s['rollback'], s['container'])
        return {**s, "status": "rolled_back"}
    return s

def node_complete(s: State) -> State:
    try:
        log(s['alert_id'], "DONE", s['status'])
        if s['status'] == "success":
            jira_close(s['ticket'], "Alert has been fixed")
        elif s['status'] == "rejected":
            jira_close(s['ticket'], "Rejected by operator")
        else:
            jira_close(s['ticket'], f"Closed: {s['status']}")
        slack_result(s['alert_name'], s['status'], s['ticket'])
    except Exception as e:
        print(f"[ERROR] complete: {e}")
    return s

#routing Functions:
def route_rate(s) -> Literal["map", "complete"]: return "map" if s["status"] == "rate_ok" else "complete"
def route_map(s) -> Literal["approval", "complete"]: return "approval" if s["status"] == "mapped" else "complete"
def route_approval(s) -> Literal["dry", "complete"]: return "dry" if s["approved"] else "complete"
def route_dry(s) -> Literal["exec", "complete"]: return "complete" if s["dry_run"] else "exec"
def route_verify(s) -> Literal["rollback", "complete"]: return "complete" if s["verified"] else ("rollback" if s["retries"] >= 3 else "exec")
def route_rollback(s) -> Literal["complete"]: return "complete"


graph = StateGraph(State)
for name, fn in [("ticket", node_ticket), ("rate", node_rate), ("map", node_map), ("approval", node_approval), ("dry", node_dry), ("exec", node_exec), ("verify", node_verify), ("rollback", node_rollback), ("complete", node_complete)]:
    graph.add_node(name, fn)
graph.set_entry_point("ticket")
graph.add_edge("ticket", "rate")
graph.add_conditional_edges("rate", route_rate)
graph.add_conditional_edges("map", route_map)
graph.add_conditional_edges("approval", route_approval)
graph.add_conditional_edges("dry", route_dry)
graph.add_edge("exec", "verify")
graph.add_conditional_edges("verify", route_verify)
graph.add_conditional_edges("rollback", route_rollback)
graph.add_edge("complete", END)
FLOW = graph.compile(checkpointer=MemorySaver())


def process(name, container, dry=False):
    id = f"{name}_{int(time.time())}"
    log(id, "START", name)
    FLOW.invoke({"alert_id": id, "alert_name": name, "container": container, "severity": "", "action": "", "rollback": "",
        "dry_run": dry, "approvals_needed": 1, "approved": False, "verified": False, "retries": 0, "status": "started", "ticket": ""}, 
        {"configurable": {"thread_id": id}})


@app.post("/webhook")
async def webhook(req: Request):
    data = await req.json()
    print(f"[WEBHOOK] Received: {data}")
    for a in data.get('alerts', []):
        print(f"[ALERT] {a.get('labels', {}).get('alertname')} - {a.get('status')}")
        if a.get('status') == 'firing':
            alertname = a['labels'].get('alertname')
            container = a['labels'].get('container', a['labels'].get('name', 'httpd-server'))
            m = ALERT_TO_TOOL.get(alertname, {})
            if m:
                threading.Thread(target=process, args=(alertname, m.get('container', container)), daemon=True).start()
            else:
                print(f"[WEBHOOK] No mapping for {alertname}")
    return {"status": "ok"}

@app.get("/approve/{id}")
async def approve(id: str):
    if id in pending_approvals:
        if pending_approvals[id]["done"] is None:
            pending_approvals[id]["count"] += 1
            if pending_approvals[id]["count"] >= pending_approvals[id]["need"]:
                pending_approvals[id]["done"] = True
            return {"status": "approved"}
        return {"status": "already_processed"}
    return {"status": "not_found"}

@app.get("/reject/{id}")
async def reject(id: str):
    if id in pending_approvals:
        pending_approvals[id]["done"] = False
        return {"status": "rejected"}
    return {"status": "not_found"}

@app.get("/test")
async def test(type: str = "httpd", dry_run: bool = False):
    m = ALERT_TO_TOOL.get("HTTPDServiceDown" if type == "httpd" else "HighCPU", {})
    threading.Thread(target=process, args=("HTTPDServiceDown" if type == "httpd" else "HighCPU", m.get("container", "httpd-server"), dry_run), daemon=True).start()
    return {"status": "triggered"}

@app.get("/health")
async def health():
    return {"status": "ok", "mcp": mcp_connected}


if __name__ == "__main__":
    threading.Thread(target=lambda: HTTPServer(('0.0.0.0', 9200), MetricsHandler).serve_forever(), daemon=True).start()
    threading.Thread(target=lambda: asyncio.run(mcp_worker()), daemon=True).start()
    subprocess.getoutput('docker exec httpd-server httpd -k start')
    time.sleep(2)
    print("Agent Started")
    uvicorn.run(app, host="0.0.0.0", port=5000, log_level="warning")
