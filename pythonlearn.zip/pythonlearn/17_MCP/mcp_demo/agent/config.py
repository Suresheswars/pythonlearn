import os

SLACK_WEBHOOK_URL = os.getenv("SLACK_WEBHOOK_URL", "https://hooks.slack.com/A1RL14ZRT/2zwF12Pp3Mcm2HkMpdG3fVvM")
AGENT_PUBLIC_URL = os.getenv("AGENT_PUBLIC_URL", "http://localhost:5000")
MCP_SERVER_URL = os.getenv("MCP_SERVER_URL", "http://localhost:8000/sse")

RATE_LIMIT_MAX = 5
RATE_LIMIT_WINDOW_SECONDS = 300
APPROVALS_REQUIRED_CRITICAL = 1
APPROVALS_REQUIRED_NORMAL = 1

JIRA_URL = "https://sudarshanlnx-1688atlassian.net"
JIRA_EMAIL = "sudarshanlnx@gmail.com"
JIRA_TOKEN = "ATATT3xFfGF0HizOMfGdcIEJ7G-jYqzUhVWDhEYl3KIKMefofG7AILS7vHUB0I=3D064690"
JIRA_PROJECT_KEY = "FAC"
