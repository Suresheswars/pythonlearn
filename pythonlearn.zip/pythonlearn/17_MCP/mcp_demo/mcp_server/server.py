import subprocess
import logging
import os

os.environ["UVICORN_LOG_LEVEL"] = "error"
logging.disable(logging.INFO)

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("remediation-tools")


def run(cmd: str) -> str:
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout.strip() or result.stderr.strip()


@mcp.tool()
def start_httpd(container: str = "httpd-server") -> str:
    """Start Apache HTTPD service"""
    return run(f"docker exec {container} httpd -k start")


@mcp.tool()
def stop_httpd(container: str = "httpd-server") -> str:
    """Stop Apache HTTPD service"""
    return run(f"docker exec {container} httpd -k stop")


@mcp.tool()
def check_httpd(container: str = "httpd-server") -> str:
    """Check if HTTPD is running"""
    result = run(f"docker exec {container} pgrep -x httpd")
    if result.strip() and result.strip()[0].isdigit():
        return "RUNNING"
    return "NOT RUNNING"


@mcp.tool()
def kill_high_cpu(container: str) -> str:
    """Restart container to fix high CPU"""
    return run(f"docker restart {container}")


@mcp.tool()
def restart_container(container: str) -> str:
    """Restart a container"""
    return run(f"docker restart {container}")


if __name__ == "__main__":
    print("MCP Server Started")
    mcp.run(transport="sse")
