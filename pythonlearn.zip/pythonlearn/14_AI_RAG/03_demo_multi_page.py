import config
from atlassian import Confluence
from bs4 import BeautifulSoup
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_openai import ChatOpenAI


def fetch_confluence_pages(page_ids):
    confluence = Confluence(
        url=config.CONFLUENCE_URL,
        username=config.CONFLUENCE_USERNAME,
        password=config.CONFLUENCE_API_TOKEN,
        cloud=True
    )
    
    pages = []
    for page_id in page_ids:
        try:
            page = confluence.get_page_by_id(page_id, expand='body.storage')
            title = page['title']
            html = page['body']['storage']['value']
            page_url = f"{config.CONFLUENCE_URL}/pages/viewpage.action?pageId={page_id}"
            pages.append({
                'id': page_id,
                'title': title,
                'html': html,
                'url': page_url
            })
            print(f"Loaded: {title}")
        except Exception as e:
            print(f"Error loading page {page_id}: {e}")
    
    return pages


def clean_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    return soup.get_text(separator="\n")


def create_chunks_with_metadata(pages):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1200,
        chunk_overlap=200
    )
    
    all_chunks = []
    all_metadata = []
    
    for page in pages:
        clean_text = clean_html(page['html'])
        chunks = splitter.split_text(clean_text)
        
        for chunk in chunks:
            all_chunks.append(chunk)
            all_metadata.append({
                'source': page['title'],
                'page_id': page['id'],
                'url': page['url']
            })
    
    return all_chunks, all_metadata


def create_vector_db(chunks, metadata):
    import os
    persist_dir = "./vector_dbs/confluence_multi"
    os.makedirs(persist_dir, exist_ok=True)
    
    embedder = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-mpnet-base-v2"
    )
    
    db = Chroma.from_texts(
        texts=chunks,
        embedding=embedder,
        metadatas=metadata,
        collection_name="confluence_multipage",
        persist_directory=persist_dir
    )
    print(f" Database saved to: {persist_dir}")
    return db


def setup_rag_pipeline(vector_db):
    llm = ChatOpenAI(
        model="gpt-4o-mini",
        api_key=config.OPENAI_API_KEY,
        temperature=0
    )
    retriever = vector_db.as_retriever(search_kwargs={"k": 5})
    return llm, retriever


def main():
    print("Multi-Page Confluence RAG System")
    print("=" * 60)
    
    print(f"\nConnecting to: {config.CONFLUENCE_URL}")
    print(f"Loading {len(config.PAGE_IDS)} pages...\n")
    
    pages = fetch_confluence_pages(config.PAGE_IDS)
    
    if not pages:
        print("\nNo pages loaded. Check your page IDs and credentials.")
        return
    
    print(f"\nSuccessfully loaded {len(pages)} pages")
    
    chunks, metadata = create_chunks_with_metadata(pages)
    print(f"Created {len(chunks)} chunks from all pages")
    
    print("Building vector database...")
    vector_db = create_vector_db(chunks, metadata)
    
    llm, retriever = setup_rag_pipeline(vector_db)
    print("RAG system ready!\n")
    
    print("=" * 60)
    print("You can now ask questions about any of the loaded pages")
    print("=" * 60)
    
    while True:
        query = input("\nQuestion (or 'q' to quit): ")
        if query.lower() == 'q':
            break
        
        docs = retriever.invoke(query)
        
        sources = set([doc.metadata['source'] for doc in docs])
        print(f"\nSources: {', '.join(sources)}")
        
        context = "\n\n".join([doc.page_content for doc in docs])
        
        if not context.strip():
            print("\nI don't know based on the provided Confluence data.\n")
            continue
        
        prompt = f"""
You MUST follow the rules strictly.

RULES:
1. You can ONLY use the information found inside the CONTEXT section.
2. If the answer is not fully present in the context, say EXACTLY:
   "I don't know based on the provided Confluence data."
3. DO NOT use your own knowledge or guess.
4. DO NOT invent commands or steps.
5. Respond in a clear, human tone.
6. If you use information from the context, mention which document it came from.

CONTEXT:
{context}

QUESTION:
{query}

ANSWER:
"""
        
        answer = llm.invoke(prompt)
        print("\nAnswer:", answer.content)
        
        print("\nReferenced pages:")
        for doc in docs:
            print(f"  - {doc.metadata['source']}")
            print(f"    {doc.metadata['url']}")
            break


if __name__ == "__main__":
    main()
