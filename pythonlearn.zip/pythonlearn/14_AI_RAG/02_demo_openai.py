import config
from atlassian import Confluence
from bs4 import BeautifulSoup
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_openai import ChatOpenAI


def fetch_confluence_page(page_id):
    confluence = Confluence(
        url=config.CONFLUENCE_URL,
        username=config.CONFLUENCE_USERNAME,
        password=config.CONFLUENCE_API_TOKEN,
        cloud=True
    )
    page = confluence.get_page_by_id(page_id, expand='body.storage')
    return page['title'], page['body']['storage']['value']


def clean_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    return soup.get_text(separator="\n")


def create_chunks(text):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1200,
        chunk_overlap=200
    )
    return splitter.split_text(text)


def create_vector_db(chunks):
    import os
    persist_dir = "./vector_dbs/confluence_openai"
    os.makedirs(persist_dir, exist_ok=True)
    
    embedder = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-mpnet-base-v2"
    )
    
    db = Chroma.from_texts(
        texts=chunks,
        embedding=embedder,
        collection_name="confluence_rag_openai",
        persist_directory=persist_dir
    )
    print(f"📁 Database saved to: {persist_dir}")
    return db


def setup_rag_pipeline(vector_db):
    llm = ChatOpenAI(
        model="gpt-4o-mini",
        api_key=config.OPENAI_API_KEY,
        temperature=0
    )
    retriever = vector_db.as_retriever(search_kwargs={"k": 4})
    return llm, retriever


def main():
    print(f"Connecting to: {config.CONFLUENCE_URL}")
    print(f"Fetching page ID: {config.PAGE_ID}")

    try:
        title, html = fetch_confluence_page(config.PAGE_ID)
        print(f"Loaded: {title}")
    except Exception as e:
        print("Error:", e)
        return

    clean_text = clean_html(html)
    chunks = create_chunks(clean_text)
    print(f"Created {len(chunks)} chunks")

    vector_db = create_vector_db(chunks)
    llm, retriever = setup_rag_pipeline(vector_db)

    print("\nSystem ready! Ask anything about your Confluence page.")

    while True:
        query = input("Question (or 'q' to quit): ")
        if query.lower() == 'q':
            break

        docs = retriever.invoke(query)
        context = "\n\n".join([doc.page_content for doc in docs])

        if not context.strip():
            print("\nI don't know based on the provided Confluence data.\n")
            continue

        prompt = f"""
You MUST follow the rules strictly.

RULES:
1. You can ONLY use the information found inside the CONTEXT section.
2. If the answer is not fully present in the context, say EXACTLY:
   "I don't know based on the provided Confluence data."
3. DO NOT use your own knowledge or guess.
4. DO NOT invent commands or steps.
5. Respond in a clear, human tone.

CONTEXT:
{context}

QUESTION:
{query}

ANSWER:
"""

        answer = llm.invoke(prompt)
        print("\nAnswer:", answer.content, "\n")


if __name__ == "__main__":
    main()
