import config
from atlassian import Confluence
from bs4 import BeautifulSoup
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_openai import ChatOpenAI


def fetch_confluence_page(page_id):
    confluence = Confluence(
        url=config.CONFLUENCE_URL,
        username=config.CONFLUENCE_USERNAME,
        password=config.CONFLUENCE_API_TOKEN,
        cloud=True
    )
    page = confluence.get_page_by_id(page_id, expand='body.storage')
    return page['title'], page['body']['storage']['value']


def clean_html(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    return soup.get_text(separator="\n")


def create_chunks(text):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1200,
        chunk_overlap=200
    )
    return splitter.split_text(text)


def create_vector_db(chunks):
    embedder = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-mpnet-base-v2"
    )

    db = Chroma.from_texts(
        texts=chunks,
        embedding=embedder,
        collection_name="confluence_rag"
    )
    return db


def setup_rag_pipeline(vector_db):
    llm = ChatOpenAI(
        model="local-model",
        base_url=config.LM_STUDIO_URL,
        api_key="not-needed",
        temperature=0,
        max_tokens=500
    )
    retriever = vector_db.as_retriever(search_kwargs={"k": 6})
    return llm, retriever


def main():
    print(f"Connecting to: {config.CONFLUENCE_URL}")
    print(f"Fetching page ID: {config.PAGE_ID}")

    try:
        title, html = fetch_confluence_page(config.PAGE_ID)
        print(f"Loaded: {title}")
    except Exception as e:
        print("Error:", e)
        return

    clean_text = clean_html(html)
    chunks = create_chunks(clean_text)
    print(f"Created {len(chunks)} chunks")

    vector_db = create_vector_db(chunks)
    llm, retriever = setup_rag_pipeline(vector_db)

    print("\nSystem ready! Ask anything about your Confluence page.\n")

    while True:
        query = input("Question (or 'q' to quit): ")
        if query.lower() == 'q':
            break

        docs = retriever.invoke(query)
        context = "\n\n".join([doc.page_content for doc in docs])

        if not context.strip():
            print("\nI don't know based on the provided Confluence data.\n")
            continue

        prompt = f"""STRICT INSTRUCTIONS: Copy/paste relevant text from CONTEXT. Do NOT generate new text.

CONTEXT:
{context}

QUESTION: {query}

RULES (MUST FOLLOW):
1. ONLY use words/sentences from CONTEXT above
2. If CONTEXT has the answer: copy the exact text
3. If CONTEXT missing answer: say "I don't know based on the provided Confluence data."
4. DO NOT create new sentences
5. DO NOT add your knowledge
6. DO NOT explain beyond CONTEXT

Answer (copy from CONTEXT):"""

        answer = llm.invoke(prompt)
        print("\nAnswer:", answer.content, "\n")


if __name__ == "__main__":
    main()
