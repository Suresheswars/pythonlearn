
-- Employees table
CREATE TABLE IF NOT EXISTS employees (
    employee_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    hire_date DATE NOT NULL,
    job_title VARCHAR(100),
    department VARCHAR(50),
    salary DECIMAL(10, 2),
    manager_id INTEGER
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    product_id SERIAL PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    price DECIMAL(10, 2),
    stock_quantity INTEGER,
    supplier VARCHAR(100),
    description TEXT
);

-- Customers table
CREATE TABLE IF NOT EXISTS customers (
    customer_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(200),
    city VARCHAR(50),
    country VARCHAR(50),
    registration_date DATE
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    order_id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES customers(customer_id),
    order_date DATE NOT NULL,
    total_amount DECIMAL(10, 2),
    status VARCHAR(20),
    shipping_address VARCHAR(200)
);

-- Insert sample data into employees
INSERT INTO employees (first_name, last_name, email, phone, hire_date, job_title, department, salary, manager_id) VALUES
('John', 'Smith', 'john.smith@company.com', '555-0101', '2020-01-15', 'Software Engineer', 'Engineering', 95000.00, NULL),
('Sarah', 'Johnson', 'sarah.johnson@company.com', '555-0102', '2019-03-20', 'Senior Developer', 'Engineering', 120000.00, 1),
('Michael', 'Williams', 'michael.williams@company.com', '555-0103', '2021-06-10', 'Data Analyst', 'Analytics', 85000.00, 1),
('Emily', 'Brown', 'emily.brown@company.com', '555-0104', '2020-11-05', 'Product Manager', 'Product', 110000.00, NULL),
('David', 'Jones', 'david.jones@company.com', '555-0105', '2022-02-14', 'UX Designer', 'Design', 90000.00, 4),
('Lisa', 'Garcia', 'lisa.garcia@company.com', '555-0106', '2018-07-22', 'HR Manager', 'Human Resources', 105000.00, NULL),
('James', 'Martinez', 'james.martinez@company.com', '555-0107', '2021-09-30', 'Sales Representative', 'Sales', 75000.00, NULL),
('Jennifer', 'Rodriguez', 'jennifer.rodriguez@company.com', '555-0108', '2020-05-18', 'Marketing Specialist', 'Marketing', 80000.00, NULL),
('Robert', 'Wilson', 'robert.wilson@company.com', '555-0109', '2019-12-01', 'DevOps Engineer', 'Engineering', 115000.00, 1),
('Maria', 'Anderson', 'maria.anderson@company.com', '555-0110', '2022-04-25', 'Quality Assurance', 'Engineering', 82000.00, 2);

-- Insert sample data into products
INSERT INTO products (product_name, category, price, stock_quantity, supplier, description) VALUES
('Laptop Pro 15', 'Electronics', 1299.99, 45, 'TechSupply Co', 'High-performance laptop with 16GB RAM and 512GB SSD'),
('Wireless Mouse', 'Electronics', 29.99, 150, 'TechSupply Co', 'Ergonomic wireless mouse with 6 buttons'),
('USB-C Hub', 'Electronics', 49.99, 200, 'ConnectTech', '7-in-1 USB-C hub with HDMI and USB 3.0 ports'),
('Office Chair', 'Furniture', 299.99, 30, 'ComfortSeating', 'Ergonomic office chair with lumbar support'),
('Standing Desk', 'Furniture', 599.99, 15, 'ComfortSeating', 'Adjustable height standing desk, electric motor'),
('Mechanical Keyboard', 'Electronics', 89.99, 75, 'TechSupply Co', 'RGB mechanical keyboard with blue switches'),
('Webcam HD', 'Electronics', 79.99, 60, 'TechSupply Co', '1080p HD webcam with built-in microphone'),
('Monitor 27"', 'Electronics', 349.99, 25, 'DisplayTech', '27-inch 4K UHD monitor with IPS panel'),
('Desk Lamp', 'Furniture', 39.99, 100, 'LightingSolutions', 'LED desk lamp with adjustable brightness'),
('Notebook Set', 'Stationery', 14.99, 250, 'PaperPlus', 'Set of 3 premium notebooks with 200 pages each');

-- Insert sample data into customers
INSERT INTO customers (first_name, last_name, email, phone, address, city, country, registration_date) VALUES
('Alice', 'Cooper', 'alice.cooper@email.com', '555-1001', '123 Main St', 'New York', 'USA', '2022-01-10'),
('Bob', 'Taylor', 'bob.taylor@email.com', '555-1002', '456 Oak Ave', 'Los Angeles', 'USA', '2022-03-15'),
('Carol', 'White', 'carol.white@email.com', '555-1003', '789 Pine Rd', 'Chicago', 'USA', '2021-11-20'),
('Daniel', 'Green', 'daniel.green@email.com', '555-1004', '321 Elm St', 'Houston', 'USA', '2023-02-05'),
('Emma', 'Black', 'emma.black@email.com', '555-1005', '654 Maple Dr', 'Phoenix', 'USA', '2022-07-12'),
('Frank', 'Blue', 'frank.blue@email.com', '555-1006', '987 Cedar Ln', 'Philadelphia', 'USA', '2021-09-30'),
('Grace', 'Silver', 'grace.silver@email.com', '555-1007', '147 Birch Ct', 'San Antonio', 'USA', '2023-01-18'),
('Henry', 'Gold', 'henry.gold@email.com', '555-1008', '258 Spruce Way', 'San Diego', 'USA', '2022-05-22'),
('Iris', 'Brown', 'iris.brown@email.com', '555-1009', '369 Willow Pl', 'Dallas', 'USA', '2021-12-14'),
('Jack', 'Gray', 'jack.gray@email.com', '555-1010', '741 Ash Blvd', 'San Jose', 'USA', '2023-03-08');

-- Insert sample data into orders
INSERT INTO orders (customer_id, order_date, total_amount, status, shipping_address) VALUES
(1, '2023-05-15', 1379.98, 'Delivered', '123 Main St, New York'),
(2, '2023-06-20', 679.98, 'Delivered', '456 Oak Ave, Los Angeles'),
(3, '2023-07-10', 429.97, 'Shipped', '789 Pine Rd, Chicago'),
(4, '2023-08-05', 949.98, 'Delivered', '321 Elm St, Houston'),
(5, '2023-09-12', 299.99, 'Processing', '654 Maple Dr, Phoenix'),
(1, '2023-10-01', 129.98, 'Delivered', '123 Main St, New York'),
(6, '2023-10-15', 599.99, 'Shipped', '987 Cedar Ln, Philadelphia'),
(7, '2023-10-22', 779.97, 'Delivered', '147 Birch Ct, San Antonio'),
(8, '2023-11-05', 1649.97, 'Delivered', '258 Spruce Way, San Diego'),
(9, '2023-11-18', 89.99, 'Processing', '369 Willow Pl, Dallas');

-- Create a view for employee information
CREATE VIEW employee_summary AS
SELECT 
    e.employee_id,
    CONCAT(e.first_name, ' ', e.last_name) AS full_name,
    e.job_title,
    e.department,
    e.salary,
    CONCAT(m.first_name, ' ', m.last_name) AS manager_name
FROM employees e
LEFT JOIN employees m ON e.manager_id = m.employee_id;

-- Create a view for order details
CREATE VIEW order_details AS
SELECT 
    o.order_id,
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    c.email,
    o.order_date,
    o.total_amount,
    o.status
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id;

GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO raguser;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO raguser;













