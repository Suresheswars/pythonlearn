import config
import psycopg2
from psycopg2.extras import RealDictCursor
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_openai import ChatOpenAI
import os


def connect_database():
    try:
        conn = psycopg2.connect(
            host=config_db.DB_HOST,
            port=config_db.DB_PORT,
            database=config_db.DB_NAME,
            user=config_db.DB_USER,
            password=config_db.DB_PASSWORD
        )
        print("Successfully connected to PostgreSQL database")
        return conn
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None


def get_table_schema(conn):
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    
    query = """
    SELECT 
        c.table_name,
        c.column_name,
        c.data_type,
        c.is_nullable,
        tc.constraint_type
    FROM information_schema.columns c
    LEFT JOIN information_schema.key_column_usage kcu 
        ON c.table_name = kcu.table_name 
        AND c.column_name = kcu.column_name
    LEFT JOIN information_schema.table_constraints tc 
        ON kcu.constraint_name = tc.constraint_name
    WHERE c.table_schema = 'public' 
        AND c.table_name NOT IN ('pg_stat_statements')
    ORDER BY c.table_name, c.ordinal_position;
    """
    
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    
    return results


def get_table_data_samples(conn):
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    
    cursor.execute("""
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_type = 'BASE TABLE'
        AND table_name NOT LIKE 'pg_%';
    """)
    
    tables = [row['table_name'] for row in cursor.fetchall()]
    samples = {}
    
    for table in tables:
        try:
            cursor.execute(f"SELECT * FROM {table} LIMIT 5;")
            samples[table] = cursor.fetchall()
        except Exception as e:
            print(f"Warning: Could not fetch data from {table}: {e}")
    
    cursor.close()
    return samples


def get_table_statistics(conn, tables):
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    stats = {}
    
    for table in tables:
        try:
            cursor.execute(f"SELECT COUNT(*) as row_count FROM {table};")
            result = cursor.fetchone()
            stats[table] = result['row_count']
        except Exception as e:
            stats[table] = 0
    
    cursor.close()
    return stats


def get_table_types(conn):
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    
    cursor.execute("""
        SELECT table_name, table_type
        FROM information_schema.tables 
        WHERE table_schema = 'public'
        AND table_name NOT LIKE 'pg_%'
        ORDER BY table_type, table_name;
    """)
    
    results = cursor.fetchall()
    cursor.close()
    
    base_tables = [r['table_name'] for r in results if r['table_type'] == 'BASE TABLE']
    views = [r['table_name'] for r in results if r['table_type'] == 'VIEW']
    
    return base_tables, views


def format_database_content(schema_info, data_samples, table_stats, base_tables, views):
    content_parts = []
    
    tables = {}
    for col in schema_info:
        table_name = col['table_name']
        if table_name not in tables:
            tables[table_name] = []
        tables[table_name].append(col)
    
    overview = f"""
DATABASE OVERVIEW
==================
This database contains {len(tables)} total objects.

BASE TABLES: {len(base_tables)} tables
VIEWS: {len(views)} views
TOTAL: {len(tables)} database objects

LIST OF BASE TABLES:
"""
    for idx, table_name in enumerate(base_tables, 1):
        row_count = table_stats.get(table_name, 0)
        overview += f"  {idx}. {table_name} ({row_count} rows)\n"
    
    if views:
        overview += f"\nLIST OF VIEWS:\n"
        for idx, view_name in enumerate(views, 1):
            overview += f"  {idx}. {view_name}\n"
    
    overview += f"""
TOTAL DATABASE SUMMARY:
- Number of base tables: {len(base_tables)}
- Number of views: {len(views)}
- Total database objects: {len(tables)}
"""
    
    for table_name in base_tables:
        if table_name in table_stats:
            overview += f"- {table_name}: {table_stats[table_name]} records\n"
    
    content_parts.append(overview)
    
    for table_name, columns in tables.items():
        table_doc = f"\n{'='*60}\n"
        table_doc += f"TABLE: {table_name.upper()}\n"
        table_doc += f"{'='*60}\n\n"
        
        table_doc += "COLUMNS:\n"
        for col in columns:
            constraint = f" [{col['constraint_type']}]" if col['constraint_type'] else ""
            table_doc += f"  - {col['column_name']}: {col['data_type']}{constraint}\n"
        
        if table_name in data_samples and data_samples[table_name]:
            table_doc += f"\nSAMPLE DATA ({len(data_samples[table_name])} rows):\n"
            for i, row in enumerate(data_samples[table_name], 1):
                table_doc += f"\n  Row {i}:\n"
                for key, value in row.items():
                    table_doc += f"    {key}: {value}\n"
        
        if table_name in table_stats:
            table_doc += f"\nTABLE STATISTICS:\n"
            table_doc += f"  Total rows: {table_stats[table_name]}\n"
            table_doc += f"  Total columns: {len(columns)}\n"
        
        content_parts.append(table_doc)
    
    return content_parts


def create_chunks(content_parts):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=config_db.CHUNK_SIZE,
        chunk_overlap=config_db.CHUNK_OVERLAP
    )
    
    all_chunks = []
    for content in content_parts:
        chunks = splitter.split_text(content)
        all_chunks.extend(chunks)
    
    return all_chunks


def create_vector_db(chunks):
    persist_dir = config_db.VECTOR_DB_PATH
    os.makedirs(persist_dir, exist_ok=True)
    
    embedder = HuggingFaceEmbeddings(
        model_name=config_db.EMBEDDING_MODEL
    )
    
    db = Chroma.from_texts(
        texts=chunks,
        embedding=embedder,
        collection_name="database_rag",
        persist_directory=persist_dir
    )
    
    print(f"Vector database saved to: {persist_dir}")
    return db


def setup_rag_pipeline(vector_db):
    llm = ChatOpenAI(
        model=config_db.OPENAI_MODEL,
        api_key=config_db.OPENAI_API_KEY,
        temperature=0
    )
    print(f"Using OpenAI model: {config_db.OPENAI_MODEL}")
    
    retriever = vector_db.as_retriever(
        search_kwargs={"k": config_db.TOP_K_RESULTS}
    )
    
    return llm, retriever


def query_database_direct(conn, user_query):
    try:
        cursor = conn.cursor(cursor_factory=RealDictCursor)
        cursor.execute(user_query)
        results = cursor.fetchall()
        cursor.close()
        return results
    except Exception as e:
        return f"Error executing query: {e}"


def main():
    print("\n" + "="*70)
    print("   DATABASE RAG SYSTEM - Query Database Tables with Natural Language")
    print("="*70 + "\n")
    
    print("Connecting to PostgreSQL database...")
    conn = connect_database()
    if not conn:
        print("Failed to connect to database. Please ensure Docker container is running.")
        print("Run: docker-compose -f docker-compose-db.yml up -d")
        return
    
    print("Loading database schema and sample data...")
    schema_info = get_table_schema(conn)
    data_samples = get_table_data_samples(conn)
    base_tables, views = get_table_types(conn)
    table_stats = get_table_statistics(conn, base_tables)
    
    print(f"Found {len(base_tables)} base tables and {len(views)} views")
    
    print("Formatting database content...")
    content_parts = format_database_content(schema_info, data_samples, table_stats, base_tables, views)
    chunks = create_chunks(content_parts)
    print(f"Created {len(chunks)} text chunks")
    
    print("Creating vector database...")
    vector_db = create_vector_db(chunks)
    
    print("Setting up RAG pipeline with OpenAI...")
    llm, retriever = setup_rag_pipeline(vector_db)
    
    print("\n" + "="*70)
    print("System ready! You can now ask questions about the database.")
    print("="*70)
    print("\nExample questions:")
    print("  - What tables are available in the database?")
    print("  - Show me information about employees")
    print("  - What products do we have in stock?")
    print("  - Tell me about customer orders")
    print("  - What is the average salary by department?")
    print("\n" + "="*70 + "\n")
    
    while True:
        user_input = input("Question (or 'q' to quit): ")
        
        if user_input.lower() in ['q', 'quit', 'exit']:
            print("\nGoodbye!")
            break
        
        if not user_input.strip():
            continue
        
        print("\nSearching database knowledge...")
        docs = retriever.invoke(user_input)
        context = "\n\n".join([doc.page_content for doc in docs])
        
        if not context.strip():
            print("\nNo relevant information found in the database.\n")
            continue
        
        prompt = f"""

STRICT RULES:
1. Use ONLY the information from the CONTEXT section below
2. If the answer is not in the context, say: "I don't have enough information to answer that question based on the current database context."
3. DO NOT make up table names, column names, or data
4. Be clear, concise, and accurate
5. If asked about specific data, refer to the sample data in the context
6. If asked about structure, refer to the table schemas in the context

CONTEXT (Database Schema and Sample Data):
{context}

QUESTION:
{user_input}

ANSWER:
"""
        
        print("Generating answer...")
        try:
            answer = llm.invoke(prompt)
            print(f"\nAnswer:\n{answer.content}\n")
        except Exception as e:
            print(f"\nError getting response from OpenAI: {e}")
            print("Check your OpenAI API key in config_db.py\n")
    
    conn.close()
    print("\nDatabase connection closed.")


if __name__ == "__main__":
    main()
