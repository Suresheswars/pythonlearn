CONFLUENCE_URL = "https://wetechzo.atlassian.net/wiki"
CONFLUENCE_USERNAME = "management@wetechzone.com"
CONFLUENCE_API_TOKEN = "ATATT3xFOj7noQE6FdummyepX39y8Pp1H7681oSe0QQ=6813B229"

OPENAI_API_KEY = "sk-proj-UakFJhAe33BF0uVFdummyrP4rOE_qGG9-5lPDi-dxZsP_zKeUa53GfHXQA"

PAGE_ID = "720897"

CONFLUENCE_SPACE_KEY = None
CONFLUENCE_LABEL = None
