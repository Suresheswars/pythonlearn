DB_HOST = "localhost"
DB_PORT = 5432
DB_NAME = "ragdatabase"
DB_USER = "raguser"
DB_PASSWORD = "ragpassword"

OPENAI_API_KEY = "sk-proj-Ua62hLFNP1o5GDQpJDwO5ewrP4rOE_qGG9-5lPDi-dxZsP_zKeUa53GfHXQA"
OPENAI_MODEL = "gpt-4o-mini"

VECTOR_DB_PATH = "./vector_dbs/database_rag"

EMBEDDING_MODEL = "sentence-transformers/all-mpnet-base-v2"

CHUNK_SIZE = 1000
CHUNK_OVERLAP = 200
TOP_K_RESULTS = 5
