GITHUB_USERNAME = 'sudarshanlnx'
GITHUB_TOKEN = 'ghp_pqX3'

OPENAI_API_KEY = "sk-proj-UaOCks2hLFNP1o5GDQpJDwO5ewrP4rOE_qGG9-5lPDi-dxZsP_zKeUa53GfHXQA"

REPO_NAMES = []
FILE_EXTENSIONS = ['.py', '.md', '.txt', '.yaml', '.yml', '.json', '.sh', '.js', '.ts', '.java', '.go']
EXCLUDE_PATHS = ['node_modules/', '__pycache__/', '.git/', 'dist/', 'build/', 'venv/', 'env/']
MAX_FILE_SIZE = 500000
MAX_FILES_PER_BRANCH = 500
BRANCH_MODE = 'all'
