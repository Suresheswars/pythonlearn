import config
import requests
import base64
import signal
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma
from langchain_openai import ChatOpenAI


class TimeoutException(Exception):
    pass

def timeout_handler(signum, frame):
    raise TimeoutException()

if hasattr(signal, "SIGALRM"):
    signal.signal(signal.SIGALRM, timeout_handler)


def github_request(url, params=None):
    headers = {
        "Authorization": f"token {config.GITHUB_TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }
    resp = requests.get(url, headers=headers, params=params)
    return (resp.json(), resp) if resp.status_code == 200 else (None, resp)


def get_all_repos():
    repos = []
    seen = set()
    per_page = 100
    url = "https://api.github.com/user/repos"
    page = 1

    while True:
        params = {"per_page": per_page, "page": page, "type": "owner"}
        data, resp = github_request(url, params)
        if not data:
            break
        for r in data:
            if r["full_name"] not in seen:
                seen.add(r["full_name"])
                repos.append(r)
        if len(data) < per_page:
            break
        page += 1

    if not repos:
        url = f"https://api.github.com/users/{config.GITHUB_USERNAME}/repos"
        page = 1
        while True:
            params = {"per_page": per_page, "page": page}
            data, resp = github_request(url, params)
            if not data:
                break
            for r in data:
                if r["full_name"] not in seen:
                    seen.add(r["full_name"])
                    repos.append(r)
            if len(data) < per_page:
                break
            page += 1

    return repos


def get_branches(owner, repo_name):
    data, resp = github_request(f"https://api.github.com/repos/{owner}/{repo_name}/branches")
    return data or []


def get_repo_tree(owner, repo_name, branch="main"):
    data, resp = github_request(
        f"https://api.github.com/repos/{owner}/{repo_name}/git/trees/{branch}", 
        params={"recursive": "1"}
    )
    if not data:
        return []
    tree = data.get("tree", [])
    return [
        item for item in tree
        if item["type"] == "blob"
        and not any(exc in item["path"] for exc in config.EXCLUDE_PATHS)
        and any(item["path"].endswith(ext) for ext in config.FILE_EXTENSIONS)
        and item.get("size", 0) <= config.MAX_FILE_SIZE
    ]


def get_file_content(owner, repo_name, file_path, branch="main", timeout=5):
    try:
        headers = {
            "Authorization": f"token {config.GITHUB_TOKEN}",
            "Accept": "application/vnd.github.v3+json"
        }
        url = f"https://api.github.com/repos/{owner}/{repo_name}/contents/{file_path}"
        resp = requests.get(url, headers=headers, params={"ref": branch})
        if resp.status_code != 200:
            return None
        data = resp.json()
        if data.get("encoding") == "base64":
            return base64.b64decode(data["content"]).decode("utf-8", errors="ignore")
        return data.get("content")
    except:
        return None


def fetch_commit_count(owner, repo_name):
    _, resp = github_request(
        f"https://api.github.com/repos/{owner}/{repo_name}/commits",
        params={"per_page": 1}
    )
    if not resp:
        return 0
    link = resp.headers.get("Link", "")
    if "rel=\"last\"" in link:
        import urllib.parse as up
        last_url = link.split(",")[1].split(";")[0].strip()[1:-1]
        qs = up.urlparse(last_url).query
        qd = dict(up.parse_qsl(qs))
        return int(qd.get("page", 1))
    return 1


def fetch_all_github_content():
    repos = get_all_repos()
    all_docs = []

    print(f"Loading {len(repos)} repositories...")

    repo_list_text = (
        "FULL GITHUB REPOSITORY LIST:\n\n" +
        "\n".join([f"- {r['name']}" for r in repos]) +
        f"\n\nTOTAL_REPOSITORIES: {len(repos)}"
    )
    all_docs.append({
        "content": repo_list_text,
        "metadata": {
            "repo": "ALL_REPOS",
            "file_path": "REPO_LIST",
            "branch": "N/A",
            "owner": config.GITHUB_USERNAME,
            "url": f"https://github.com/{config.GITHUB_USERNAME}?tab=repositories"
        }
    })

    for idx, repo in enumerate(repos, 1):
        repo_name = repo["name"]
        owner      = repo["owner"]["login"]
        repo_url   = repo["html_url"]

        print(f"[{idx}/{len(repos)}] {repo_name}...", end=" ", flush=True)

        try:
            repo_info = (
                f"REPOSITORY METADATA\n"
                f"NAME: {repo_name}\n"
                f"OWNER: {owner}\n"
                f"DEFAULT_BRANCH: {repo.get('default_branch','main')}\n"
                f"PRIVATE: {repo.get('private', False)}\n"
                f"DESCRIPTION: {repo.get('description','None')}\n"
            )

            all_docs.append({
                "content": repo_info,
                "metadata": {
                    "repo": repo_name,
                    "file_path": "REPO_INFO",
                    "branch": "REPO_METADATA",
                    "owner": owner,
                    "url": repo_url
                }
            })

            branches = get_branches(owner, repo_name)
            branch_names = [b["name"] for b in branches]

            branch_doc = (
                f"BRANCH INFORMATION FOR {repo_name}\n"
                f"TOTAL_BRANCHES: {len(branch_names)}\n"
                f"BRANCHES:\n" +
                "\n".join([f"- {b}" for b in branch_names])
            )

            all_docs.append({
                "content": branch_doc,
                "metadata": {
                    "repo": repo_name,
                    "file_path": "BRANCH_INFO",
                    "branch": "BRANCH_METADATA",
                    "owner": owner,
                    "url": repo_url
                }
            })

            commit_count = fetch_commit_count(owner, repo_name)

            commit_doc = (
                f"COMMIT INFORMATION FOR {repo_name}\n"
                f"TOTAL_COMMITS: {commit_count}\n"
            )

            all_docs.append({
                "content": commit_doc,
                "metadata": {
                    "repo": repo_name,
                    "file_path": "COMMIT_INFO",
                    "branch": "COMMIT_METADATA",
                    "owner": owner,
                    "url": repo_url
                }
            })

            default_branch = repo.get("default_branch", "main")
            files = get_repo_tree(owner, repo_name, default_branch)

            file_paths = [f["path"] for f in files]

            file_doc = (
                f"FILE STRUCTURE FOR {repo_name}\n"
                f"TOTAL_FILES: {len(file_paths)}\n" +
                "\n".join([f"- {p}" for p in file_paths])
            )

            all_docs.append({
                "content": file_doc,
                "metadata": {
                    "repo": repo_name,
                    "file_path": "FILE_STRUCTURE",
                    "branch": default_branch,
                    "owner": owner,
                    "url": repo_url
                }
            })

            for f in files[:config.MAX_FILES_PER_BRANCH]:
                content = get_file_content(owner, repo_name, f["path"], default_branch)
                if content:
                    all_docs.append({
                        "content": content,
                        "metadata": {
                            "repo": repo_name,
                            "file_path": f["path"],
                            "branch": default_branch,
                            "owner": owner,
                            "url": f"{repo_url}/blob/{default_branch}/{f['path']}"
                        }
                    })

            print("✓")

        except Exception as e:
            print(f"✗ error: {e}")
            continue

    return all_docs


def create_chunks_with_metadata(documents):
    splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150)
    chunks, metas = [], []
    for doc in documents:
        for chunk in splitter.split_text(doc["content"]):
            chunks.append(chunk)
            metas.append(doc["metadata"])
    return chunks, metas

def create_vector_db(chunks, metadata):
    db = Chroma.from_texts(
        texts=chunks,
        metadatas=metadata,
        embedding=HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2"),
        collection_name="github_rag",
        persist_directory="./vector_dbs/github"
    )
    return db


def setup_rag_pipeline(vector_db):
    llm = ChatOpenAI(
        model="gpt-4o-mini",
        api_key=config.OPENAI_API_KEY,
        temperature=0
    )
    retriever = vector_db.as_retriever(search_kwargs={"k": 15})
    return llm, retriever


def main():
    import os
    print("Initializing GitHub RAG v5...\n")

    if os.path.exists("./vector_dbs/github"):
        print("Loading existing DB...")
        vector_db = Chroma(
            persist_directory="./vector_dbs/github",
            embedding_function=HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2"),
            collection_name="github_rag",
        )
    else:
        print("Building new database...")
        docs = fetch_all_github_content()
        chunks, meta = create_chunks_with_metadata(docs)
        vector_db = create_vector_db(chunks, meta)

    llm, retriever = setup_rag_pipeline(vector_db)
    print("\nREADY! Ask anything about your GitHub repos.\n")

    while True:
        query = input("\nQuestion (or 'q' to quit): ").strip()
        if query.lower() == "q":
            break

        docs = retriever.invoke(query)
        if not docs:
            print("No relevant documents found.")
            continue

        context = "\n\n---\n\n".join([
            f"[Repo: {d.metadata['repo']}] [File: {d.metadata['file_path']}]\n\n{d.page_content}"
            for d in docs
        ])

        prompt = f"""
Follow the rules strictly.

RULES:
1. Answer ONLY from the CONTEXT.
2. If the answer is not FULLY in the context, respond exactly:
   "I don't know based on the provided GitHub repositories."
3. No assumptions. No hallucination.

CONTEXT:
{context}

QUESTION:
{query}

ANSWER:
"""

        ans = llm.invoke(prompt)
        print("\nAnswer:", ans.content)

if __name__ == "__main__":
    main()
