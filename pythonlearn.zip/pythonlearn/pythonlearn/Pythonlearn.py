print ("Python learn")
